extends SceneTree
var failures: int = 0
var checks: int = 0
func _initialize() -> void:
	call_deferred("run_tests")
func check(value: bool, label: String) -> void:
	checks += 1
	if !value:
		failures += 1
		push_error("FAIL: " + label)
	else:
		print("PASS: " + label)
func run_tests() -> void:
	await process_frame
	var transfer: Node = root.get_node("MultiplayerFileTransfer")
	var lobby: Node = root.get_node("MultiplayerLobby")
	check(ProjectSettings.globalize_path("user://").contains("ChoicerVoicer-MP-Experimental"), "isolated user data")
	for safe: String in ["game/packs_voice/My pack", "audio/clip.wav"]:
		check(transfer._safe_relative_path(safe), "accept path " + safe)
	for unsafe: String in ["../save.json", "/absolute", "C:/Windows", "a/../b", "a\\b", "a//b", "a./b"]:
		check(!transfer._safe_relative_path(unsafe), "reject path " + unsafe)
	var folder: String = "user://test_hash"
	DirAccess.make_dir_recursive_absolute(folder)
	var bytes: PackedByteArray = PackedByteArray()
	bytes.resize(2 * 1024 * 1024 + 17)
	bytes.fill(83)
	var f: FileAccess = FileAccess.open(folder.path_join("clip.bin"), FileAccess.WRITE)
	f.store_buffer(bytes)
	f.close()
	var expected: HashingContext = HashingContext.new()
	expected.start(HashingContext.HASH_SHA256)
	expected.update("clip.bin".to_utf8_buffer())
	expected.update(bytes)
	check(transfer.compute_folder_hash(folder) == expected.finish().hex_encode(), "streaming hash matches original algorithm across multiple blocks")
	var signals: Array[String] = []
	transfer.transfer_failed.connect(func(id: String, _reason: String): signals.append(id))
	transfer._incoming["stale"] = {"from_peer": 22, "last_activity": -70000}
	transfer._process(0.0)
	check(!transfer._incoming.has("stale") and signals.has("stale"), "stalled receive is cleared and reported")
	transfer._incoming["left"] = {"from_peer": 22, "last_activity": Time.get_ticks_msec()}
	transfer._on_peer_left(22)
	check(!transfer._incoming.has("left") and signals.has("left"), "disconnect clears incomplete receive")
	var join_errors: Array[String] = []
	lobby.join_lobby_failed.connect(func(reason: String): join_errors.append(reason))
	lobby._awaiting_first_host_connection = true
	lobby._on_peer_connect_wait_timeout()
	check(!join_errors.is_empty() and !lobby._awaiting_first_host_connection, "connection timeout reports failure instead of false success")
	for i: int in range(250): lobby._log_entry("test", str(i))
	check(lobby.chat_log_history.size() == 200, "chat history stays bounded")
	var world_scene: PackedScene = load("res://scene/singleton/world.tscn")
	check(world_scene != null and world_scene.can_instantiate(), "main world loads")
	root.get_node("M").data.player.first_time = false
	var world: Node = world_scene.instantiate()
	root.add_child(world)
	await create_timer(4.0).timeout
	world.enter_multiplayer_lobby()
	await create_timer(4.0).timeout
	check(lobby.is_on_lobby_screen, "multiplayer lobby screen opens")
	if DisplayServer.get_name() != "headless":
		await RenderingServer.frame_post_draw
		root.get_texture().get_image().save_png(ProjectSettings.globalize_path("res://../lobby-preview.png"))
	print("TEST_RESULT: %s checks, %s failures" % [checks, failures])
	world.queue_free()
	await process_frame
	quit(1 if failures else 0)


