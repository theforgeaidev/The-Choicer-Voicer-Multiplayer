extends Node
var server: bool
var transfer: Node
var source_dir: String = "user://transfer_test_source"
var net_api: SceneMultiplayer
func _ready() -> void:
	server = OS.get_cmdline_user_args().has("server")
	net_api = SceneMultiplayer.new()
	get_tree().set_multiplayer(net_api, get_path())
	var peer: ENetMultiplayerPeer = ENetMultiplayerPeer.new()
	var err: int = peer.create_server(29483, 1) if server else peer.create_client("127.0.0.1", 29483)
	if err != OK:
		push_error("ENet test setup failed")
		get_tree().quit(1)
		return
	net_api.multiplayer_peer = peer
	transfer = load("res://common/globals/multiplayer/multiplayer_file_transfer.gd").new()
	transfer.name = "Transfer"
	add_child(transfer)
	transfer.transfer_failed.connect(func(id: String, why: String): push_error(id + ": " + why); get_tree().quit(1))
	if server:
		DirAccess.make_dir_recursive_absolute(source_dir.path_join("nested"))
		var payload: PackedByteArray = PackedByteArray()
		payload.resize(3 * 1024 * 1024 + 31)
		for i: int in payload.size(): payload[i] = i % 251
		var f: FileAccess = FileAccess.open(source_dir.path_join("nested/audio.bin"), FileAccess.WRITE)
		f.store_buffer(payload)
		f.close()
		f = FileAccess.open(source_dir.path_join("empty.txt"), FileAccess.WRITE)
		f.close()
		net_api.peer_connected.connect(func(id: int): transfer.send_folder(id, source_dir, "integration", "game/transfer_test_received"))
	else:
		transfer.transfer_completed.connect(_completed)
	get_tree().create_timer(25.0).timeout.connect(func(): push_error("Transfer test timed out"); get_tree().quit(1))
func _completed(_id: String, path: String) -> void:
	var matched: bool = transfer.compute_folder_hash(path) == transfer.compute_folder_hash(source_dir)
	print("TRANSFER_CLIENT: ", matched, ", bytes=3145759, includes nested and empty files")
	_result.rpc_id(1, matched)
	await get_tree().create_timer(0.5).timeout
	get_tree().quit(0 if matched else 1)
@rpc("any_peer", "reliable")
func _result(matched: bool) -> void:
	print("TRANSFER_SERVER: ", matched)
	get_tree().quit(0 if matched else 1)
