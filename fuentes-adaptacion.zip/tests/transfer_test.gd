extends SceneTree
func _initialize() -> void:
	call_deferred("start")
func start() -> void:
	var node: Node = Node.new()
	node.name = "TransferTest"
	node.set_script(load("res://tests/transfer_peer.gd"))
	root.add_child(node)
