extends MenuBase

@onready var panel_choose: VBoxContainer = %PanelChoose
@onready var panel_lobby: VBoxContainer = %PanelLobby

@onready var btn_host: ButtonCV = %BtnHost
@onready var btn_join: ButtonCV = %BtnJoin
@onready var line_join_code: LineEdit = %LineJoinCode
@onready var lbl_friends_header: Label = %LblFriendsHeader
@onready var friends_list: VBoxContainer = %FriendsList
@onready var opt_character_portrait: OptionButton = %OptCharacterPortrait
@onready var tex_character_thumbnail: TextureRect = %TexCharacterThumbnail
var _friend_rescan_timer: Timer = null

@onready var lbl_lobby_code: Label = %LblLobbyCode
@onready var btn_copy_code: ButtonCV = %BtnCopyCode
@onready var list_players: ItemList = %ListPlayers
@onready var lbl_status: Label = %LblStatus

@onready var lbl_pack_name: Label = %LblPackName
@onready var btn_choose_pack: ButtonCV = %BtnChoosePack
@onready var list_characters: VBoxContainer = %ListCharacters
@onready var chk_chronological: CheckBox = %ChkChronological
@onready var btn_start_round: ButtonCV = %BtnStartRound

@onready var chat_log: VBoxContainer = %ChatLog
@onready var chat_log_scroll: ScrollContainer = %ChatLogScroll
@onready var line_chat_input: LineEdit = %LineChatInput
@onready var btn_send_chat: ButtonCV = %BtnSendChat


func _ready() -> void :
	MultiplayerLobby.is_on_lobby_screen = true
	btn_host.button_clicked.connect(_on_host_pressed)
	btn_join.button_clicked.connect(_on_join_pressed)
	btn_choose_pack.button_clicked.connect(_on_choose_pack_pressed)
	btn_start_round.button_clicked.connect(_on_start_round_pressed)
	chk_chronological.toggled.connect(_on_chronological_toggled)
	btn_copy_code.button_clicked.connect(_on_copy_code_pressed)
	btn_send_chat.button_clicked.connect(_on_send_chat_pressed)
	line_chat_input.text_submitted.connect( func(_t: String): _on_send_chat_pressed())

	MultiplayerLobby.signaling_server_connection_failed.connect( func(reason: String): _set_status("Connection failed: %s" % reason))
	MultiplayerLobby.hosting_failed.connect( func(reason: String): _set_status("Couldn't start hosting: %s" % reason))
	MultiplayerLobby.lobby_code_upgraded.connect(_on_lobby_code_upgraded)
	MultiplayerLobby.lobby_created.connect(_on_lobby_ready)
	MultiplayerLobby.lobby_joined.connect(_on_lobby_ready)
	MultiplayerLobby.join_lobby_failed.connect( func(reason: String): _set_status("Couldn't join: %s" % reason))
	MultiplayerLobby.player_joined.connect( func(id: int): _refresh_player_list())
	MultiplayerLobby.player_left.connect(_on_player_left)
	MultiplayerLobby.player_connection_ready.connect( func(_id: int): _refresh_player_list())
	MultiplayerLobby.peer_name_resolved.connect( func(_id: int): _refresh_player_list();_refresh_characters())
	MultiplayerLobby.peer_avatar_resolved.connect( func(_id: int): _refresh_player_list())
	MultiplayerLobby.chat_log_entry_added.connect(_on_chat_log_entry_added)
	_populate_chat_log_from_history()

	MultiplayerGameState.available_characters_changed.connect(_refresh_characters)
	MultiplayerGameState.character_claims_changed.connect(_refresh_characters)
	MultiplayerGameState.phase_changed.connect(_on_phase_changed)
	MultiplayerSceneRouter.pack_readiness_changed.connect(_on_pack_readiness_changed)

	MultiplayerPackSync.verifying_pack.connect( func(): _set_status("Checking if you already have this pack..."))
	MultiplayerPackSync.transfer_needed.connect( func(_from: int, total_bytes: int): _set_status("Downloading pack from host (%s)..." % _format_bytes(total_bytes)))
	MultiplayerPackSync.transfer_progress.connect( func(done: int, total: int): _set_status("Downloading pack... %s / %s" % [_format_bytes(done), _format_bytes(total)]))
	MultiplayerPackSync.pack_sync_failed.connect( func(reason: String): _set_status("Pack sync failed: %s" % reason))
	MultiplayerPackSync.download_confirmation_needed.connect(_on_download_confirmation_needed)



	MultiplayerGameState.player_statuses_changed.connect(_refresh_player_list)
	MultiplayerGameState.game_in_progress_notice.connect(_on_game_in_progress_notice)

	_populate_character_portrait_dropdown()
	opt_character_portrait.item_selected.connect(_on_character_portrait_selected)

	MultiplayerLobby.joinable_friend_found.connect(_on_joinable_friend_found)
	MultiplayerLobby.friend_scan_finished.connect(_on_friend_scan_finished)
	MultiplayerLobby.friend_avatar_resolved.connect(_on_friend_avatar_resolved)




	if !MultiplayerLobby.lobby_code.is_empty():
		_on_lobby_ready(MultiplayerLobby.lobby_code)
	else:
		panel_choose.show();panel_lobby.hide()
		_start_friend_scan()
		_set_status("Steam listo. Todos deben usar esta misma version experimental." if MultiplayerLobby._steam_ready else "Abre Steam e inicia sesion antes de crear o unirte a una sala.")


func _exit_tree() -> void :
	MultiplayerLobby.is_on_lobby_screen = false


func _on_host_pressed() -> void :
	_set_status("Hosting a lobby...")
	MultiplayerLobby.host_lobby()


func _on_join_pressed() -> void :
	var code: String = line_join_code.text.strip_edges()
	if code.is_empty():
		_set_status("Enter a lobby code first.")
		return
	_set_status("Joining %s..." % code)
	MultiplayerLobby.join_lobby(code)


func _start_friend_scan() -> void :
	for child: Node in friends_list.get_children(): child.queue_free()
	lbl_friends_header.text = "Checking for friends already playing..."
	MultiplayerLobby.scan_for_joinable_friends()




	if _friend_rescan_timer: return
	_friend_rescan_timer = Timer.new()
	_friend_rescan_timer.wait_time = 10.0
	_friend_rescan_timer.timeout.connect(_on_friend_rescan_tick)
	add_child(_friend_rescan_timer)
	_friend_rescan_timer.start()


func _on_friend_rescan_tick() -> void :
	if !panel_choose.visible: return
	for child: Node in friends_list.get_children(): child.queue_free()
	MultiplayerLobby.scan_for_joinable_friends()


func _on_joinable_friend_found(steam_id: int, friend_name: String, lobby_id: int) -> void :
	lbl_friends_header.text = "Friends already playing:"
	var row: Button = Button.new()
	row.custom_minimum_size = Vector2(0, 44)
	row.text = "Join %s's lobby" % friend_name
	row.expand_icon = true
	row.set_meta("steam_id", steam_id)
	var existing_avatar: ImageTexture = MultiplayerLobby.get_friend_avatar(steam_id)
	if existing_avatar: row.icon = existing_avatar
	row.pressed.connect( func(): _on_friend_lobby_clicked(lobby_id))
	friends_list.add_child(row)


func _on_friend_avatar_resolved(steam_id: int) -> void :


	var texture: ImageTexture = MultiplayerLobby.get_friend_avatar(steam_id)
	if !texture: return
	for child: Node in friends_list.get_children():
		if child is Button and child.get_meta("steam_id", 0) == steam_id:
			child.icon = texture
			return


func _on_friend_lobby_clicked(lobby_id: int) -> void :
	_set_status("Joining friend's lobby...")
	MultiplayerLobby.join_lobby(str(lobby_id))


func _populate_character_portrait_dropdown() -> void :
	opt_character_portrait.clear()
	var options: Array[String] = ["Default"]
	for folder_name: String in DirAccess.get_directories_at("user://game/packs_player/"):
		options.append(folder_name)

	var current_selection_index: int = 0
	for i: int in options.size():
		opt_character_portrait.add_item(options[i])
		opt_character_portrait.set_item_metadata(i, options[i])
		if options[i] == Profile.contestant: current_selection_index = i

	opt_character_portrait.select(current_selection_index)
	_update_character_thumbnail(options[current_selection_index])


	MultiplayerCharacterSync.announce_my_character("game/packs_player/" + options[current_selection_index])


func _on_character_portrait_selected(index: int) -> void :
	var folder_name: String = opt_character_portrait.get_item_metadata(index)
	Profile.contestant = folder_name




	M.config.player = M.uc.get_json(M.OVEEP.PLAYER, "config_player")
	_update_character_thumbnail(folder_name)
	MultiplayerCharacterSync.announce_my_character("game/packs_player/" + folder_name)


func _update_character_thumbnail(folder_name: String) -> void :






	var dir_path: String = "user://game/packs_player/%s/" % folder_name
	var dir: DirAccess = DirAccess.open(dir_path)
	if !dir:
		tex_character_thumbnail.texture = null
		return
	dir.list_dir_begin()
	var entry: String = dir.get_next()
	var image_path: String = ""
	while entry != "":
		var lower: String = entry.to_lower()
		if lower.ends_with(".png") or lower.ends_with(".jpg") or lower.ends_with(".jpeg"):
			image_path = dir_path.path_join(entry)
			break
		entry = dir.get_next()
	dir.list_dir_end()
	if image_path.is_empty():
		tex_character_thumbnail.texture = null
		return
	var img: Image = Image.load_from_file(image_path)
	tex_character_thumbnail.texture = ImageTexture.create_from_image(img) if img else null


func _on_friend_scan_finished() -> void :
	if friends_list.get_child_count() == 0:
		lbl_friends_header.text = "No friends currently playing"


func _on_download_confirmation_needed(pack_name: String) -> void :
	var dialog: ConfirmationDialog = ConfirmationDialog.new()
	dialog.title = "Pack Download"
	dialog.dialog_text = "You don't have this pack:\n\n%s\n\nDownload it from the host?" % pack_name
	dialog.ok_button_text = "Download"
	dialog.cancel_button_text = "No thanks"
	dialog.confirmed.connect( func():
		_set_status("Starting download...")
		MultiplayerPackSync.confirm_download()
		dialog.queue_free()
	)
	dialog.canceled.connect( func():
		MultiplayerPackSync.decline_download()
		dialog.queue_free()
	)
	add_child(dialog)
	dialog.popup_centered()


func _on_lobby_ready(_code: String) -> void :
	panel_choose.hide();panel_lobby.show()
	btn_choose_pack.visible = MultiplayerGameState.is_host()
	chk_chronological.visible = MultiplayerGameState.is_host()
	btn_start_round.visible = MultiplayerGameState.is_host()
	_refresh_player_list()
	_refresh_pack_display()
	_refresh_characters()










	_populate_character_portrait_dropdown()

	if MultiplayerGameState.is_host():


		_update_hosting_display()
	else:
		lbl_lobby_code.text = "Connected to: %s" % MultiplayerLobby.lobby_code
		_set_status("Waiting for players...")




	MultiplayerGameState.set_my_status(MultiplayerGameState.PLAYER_STATUS.IN_HUB)


func _on_lobby_code_upgraded(_code: String, _via_upnp: bool) -> void :



	if !MultiplayerGameState.is_host(): return
	_update_hosting_display()


func _update_hosting_display() -> void :





	lbl_lobby_code.text = "Lobby Code: %s" % MultiplayerLobby.lobby_code
	_set_status("Ready to host - invite a friend, or share the code above.")


func _on_player_left(peer_id: int) -> void :





	_refresh_player_list()
	_refresh_start_round_availability()


func BackButtonPressed() -> void :





	if !MultiplayerLobby.lobby_code.is_empty():
		MultiplayerLobby.leave_lobby()
		MultiplayerGameState.reset()


func _on_choose_pack_pressed() -> void :
	if !MultiplayerGameState.is_host(): return
	M.session_type = M.SESSION_TYPE.VIDEO_DUB
	Metro.clip_selection_page_back_path = "res://scenes/nav_specific/multiplayer/multiplayer_lobby_screen.tscn"
	call_slide("res://scenes/nav_specific/clip_selector_menus/clip_selection_dub.tscn", false)


func _on_start_round_pressed() -> void :
	if !MultiplayerGameState.is_host(): return
	if MultiplayerGameState.resolved_clip_order.is_empty():
		_set_status("Choose a pack first.")
		return
	if !MultiplayerGameState.everyone_in_hub():
		_set_status("Waiting for everyone in the hub.")
		return
	if !MultiplayerSceneRouter.everyone_pack_ready():
		_set_status("Syncing pack for everyone...")
		return
	MultiplayerGameState.host_start_round()


func _on_chronological_toggled(on: bool) -> void :
	if MultiplayerGameState.is_host(): MultiplayerGameState.host_set_chronological_mode(on)


func _on_copy_code_pressed() -> void :
	if MultiplayerLobby.lobby_code.is_empty(): return
	DisplayServer.clipboard_set(MultiplayerLobby.lobby_code)






	var label: Label = btn_copy_code.get_child(0)
	if label:
		label.text = "Copied!"
		await get_tree().create_timer(1.0).timeout
		label.text = "Copy"










const JOIN_LEAVE_COLOR: Color = Color(1.0, 0.92, 0.15)
const CHAT_COLOR: Color = Color(1.0, 1.0, 1.0)

func _on_send_chat_pressed() -> void :
	MultiplayerLobby.send_chat_message(line_chat_input.text)
	line_chat_input.text = ""




	await get_tree().process_frame
	line_chat_input.grab_focus()


func _unhandled_input(event: InputEvent) -> void :










	if !(event is InputEventKey) or !event.pressed: return
	if event.keycode != KEY_ENTER and event.keycode != KEY_KP_ENTER: return
	if !panel_lobby.visible: return
	var focused: Control = get_viewport().gui_get_focus_owner()
	if focused is LineEdit or focused is TextEdit: return
	line_chat_input.grab_focus()
	get_viewport().set_input_as_handled()


func _populate_chat_log_from_history() -> void :
	for child: Node in chat_log.get_children(): child.queue_free()
	for entry: Dictionary in MultiplayerLobby.chat_log_history:
		_render_log_entry(entry)


func _on_chat_log_entry_added(entry: Dictionary) -> void :
	_render_log_entry(entry)
	_scroll_chat_to_bottom()


func _render_log_entry(entry: Dictionary) -> void :
	var label: Label = Label.new()
	label.text = entry.get("text", "")
	label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	label.add_theme_font_size_override("font_size", 14)
	match entry.get("type", "chat"):
		"joined", "left": label.add_theme_color_override("font_color", JOIN_LEAVE_COLOR)
		_: label.add_theme_color_override("font_color", CHAT_COLOR)
	chat_log.add_child(label)


func _scroll_chat_to_bottom() -> void :



	await get_tree().process_frame
	chat_log_scroll.scroll_vertical = int(chat_log_scroll.get_v_scroll_bar().max_value)


func _on_phase_changed(phase: MultiplayerGameState.PHASE) -> void :
	if phase == MultiplayerGameState.PHASE.PLAYING and !MultiplayerGameState.is_host():
		_set_status("Round starting...")


func _on_pack_readiness_changed(ready_count: int, total_count: int) -> void :
	if MultiplayerGameState.is_host():
		_set_status("Pack ready: %s/%s players" % [ready_count, total_count])
	_refresh_start_round_availability()


func _refresh_pack_display() -> void :
	if MultiplayerGameState.resolved_clip_order.is_empty():
		lbl_pack_name.text = "No pack selected yet"
	else:
		var name_guess: String = MultiplayerGameState.selected_pack_folder_relative.get_file()
		lbl_pack_name.text = "Pack: %s (%s clips)" % [name_guess, MultiplayerGameState.resolved_clip_order.size()]
		if !MultiplayerGameState.is_host() and MultiplayerSceneRouter.my_pack_ready:






			_set_status("Host picked a pack - claim a character below!")
	chk_chronological.button_pressed = MultiplayerGameState.chronological_mode
	_refresh_start_round_availability()


func _refresh_start_round_availability() -> void :
	if !btn_start_round.visible: return
	var has_pack: bool = !MultiplayerGameState.resolved_clip_order.is_empty()
	var in_hub: bool = MultiplayerGameState.everyone_in_hub()
	var packs_ready: bool = MultiplayerSceneRouter.everyone_pack_ready()
	btn_start_round.enable(has_pack and in_hub and packs_ready)


func _refresh_characters() -> void :
	for child: Node in list_characters.get_children(): child.queue_free()
	_refresh_pack_display()

	for character: String in MultiplayerGameState.available_characters:
		var row: HBoxContainer = HBoxContainer.new()
		row.add_theme_constant_override("separation", 12)

		var claimant_id: int = MultiplayerGameState.character_claims.get(character, -1)
		var lbl: Label = Label.new()
		var claim_text: String = "unclaimed" if claimant_id == -1 else MultiplayerLobby.get_display_name(claimant_id)
		lbl.text = "%s — %s" % [character, claim_text]
		lbl.add_theme_color_override("font_color", Color.WHITE)
		lbl.add_theme_color_override("font_outline_color", Color.BLACK)
		lbl.add_theme_constant_override("outline_size", 4)
		lbl.size_flags_horizontal = Control.SIZE_EXPAND_FILL








		lbl.clip_text = true
		lbl.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
		row.add_child(lbl)

		var btn: Button = Button.new()
		btn.custom_minimum_size = Vector2(80, 0)
		if claimant_id == -1:
			btn.text = "Claim"
			btn.pressed.connect(MultiplayerGameState.claim_character.bind(character))
		elif claimant_id == MultiplayerLobby.my_peer_id:
			btn.text = "Unclaim"
			btn.pressed.connect(MultiplayerGameState.unclaim_character.bind(character))
		else:
			btn.text = "Taken"
			btn.disabled = true
		row.add_child(btn)

		list_characters.add_child(row)


func _format_bytes(bytes: int) -> String:
	if bytes >= 1024 * 1024: return "%.1f MB" % (bytes / float(1024 * 1024))
	if bytes >= 1024: return "%.0f KB" % (bytes / 1024.0)
	return "%s B" % bytes


func _on_game_in_progress_notice(pack_name: String, current_clip: int, total_clips: int) -> void :
	_set_status("Round in progress - %s (%s/%s lines). You'll join next round." % [pack_name, current_clip, total_clips])


func _refresh_player_list() -> void :
	list_players.clear()
	var pack_selected: bool = !MultiplayerGameState.resolved_clip_order.is_empty()
	for id: int in MultiplayerLobby.connected_player_ids:



		var prefix: String = "* " if id == 1 else ""
		var suffix: String = ""
		var status_color: Color = Color(1, 1, 1)
		if pack_selected:
			match MultiplayerGameState.get_pack_status(id):
				MultiplayerGameState.PACK_STATUS.READY:
					suffix += " - has pack"
					status_color = Color(0.45, 0.9, 0.45)
				MultiplayerGameState.PACK_STATUS.DOWNLOADING:
					suffix += " - downloading"
					status_color = Color(0.55, 0.75, 1.0)
				MultiplayerGameState.PACK_STATUS.REFUSED:
					suffix += " - refused"
					status_color = Color(1.0, 0.45, 0.45)
				_:
					suffix += " - checking"
					status_color = Color(0.7, 0.7, 0.7)
		var avatar: ImageTexture = MultiplayerLobby.get_avatar_texture(id)
		var display_name: String = MultiplayerLobby.get_display_name(id)
		var label: String = "%s%s%s" % [prefix, display_name, suffix]
		if avatar: list_players.add_item(label, avatar)
		else: list_players.add_item(label)
		if pack_selected:
			list_players.set_item_custom_fg_color(list_players.get_item_count() - 1, status_color)
	_refresh_start_round_availability()


func _set_status(text: String) -> void :
	lbl_status.text = text
