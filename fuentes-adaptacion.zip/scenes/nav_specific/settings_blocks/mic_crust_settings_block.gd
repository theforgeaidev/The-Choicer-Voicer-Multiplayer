extends VBoxContainer


@onready var save_line: HBoxContainer = %SaveLine
@onready var btn_open_save: ButtonCV = %BtnOpenSave
@onready var btn_save: ButtonCV = %BtnSave
@onready var line_crust_profile_name: LineEdit = %LineCrustProfileName
@onready var lbl_btn_save: Label = %LblBtnSave

@onready var option_crust_profiles: OptionButton = %OptionCrustProfiles

@onready var chk_compressor: CheckButton = %ChkCompressor
@onready var slider_compressor_threshold: HSlider = %SliderCompressorThreshold
@onready var slider_compressor_gain: HSlider = %SliderCompressorGain
@onready var chk_limiter: CheckButton = %ChkLimiter
@onready var slider_limiter_ceiling: HSlider = %SliderLimiterCeiling
@onready var slider_limiter_threshold: HSlider = %SliderLimiterThreshold
@onready var chk_cutoff: CheckButton = %ChkCutoff
@onready var slider_cutoff_high_pass: HSlider = %SliderCutoffHighPass
@onready var slider_cutoff_low_pass: HSlider = %SliderCutoffLowPass
@onready var chk_distortion: CheckButton = %ChkDistortion
@onready var slider_distortion_pre_gain: HSlider = %SliderDistortionPreGain
@onready var slider_distortion_drive: HSlider = %SliderDistortionDrive
@onready var slider_distortion_post_gain: HSlider = %SliderDistortionPostGain
@onready var chk_sample_rate: CheckButton = %ChkSampleRate
@onready var slider_sample_rate_index: HSlider = %SliderSampleRateReduction
@onready var slider_mic_input_volume: HSlider = %SliderMicInputVolume
@onready var slider_mic_multiplier: HSlider = %SliderMicMultiplier
@onready var chk_reverb: CheckButton = %ChkReverb
@onready var slider_reverb_room_size: HSlider = %SliderReverbRoomSize
@onready var slider_reverb_wet: HSlider = %SliderReverbWet
@onready var chk_delay: CheckButton = %ChkDelay
@onready var slider_delay_time: HSlider = %SliderDelayTime
@onready var slider_delay_feedback: HSlider = %SliderDelayFeedback
@onready var chk_panner: CheckButton = %ChkPanner
@onready var slider_panner_pan: HSlider = %SliderPannerPan
@onready var chk_pitch: CheckButton = %ChkPitch
@onready var slider_pitch_scale: HSlider = %SliderPitchScale

@onready var lbl_compressor_threshold: Label = %LblCompressorThreshold
@onready var lbl_compressor_gain: Label = %LblCompressorGain
@onready var lbl_cutoff_high_pass: Label = %LblCutoffHighPass
@onready var lbl_cutoff_low_pass: Label = %LblCutoffLowPass
@onready var lbl_distortion_pre_gain: Label = %LblDistortionPreGain
@onready var lbl_distortion_drive: Label = %LblDistortionDrive
@onready var lbl_distortion_post_gain: Label = %LblDistortionPostGain
@onready var lbl_limiter_ceiling: Label = %LblLimiterCeiling
@onready var lbl_limiter_threshold: Label = %LblLimiterThreshold
@onready var lbl_sample_rate_reduction: Label = %LblSampleRateReduction
@onready var lbl_mic_input_volume: Label = %LblMicInputVolume
@onready var lbl_mic_multiplier: Label = %LblMicMultiplier
@onready var lbl_reverb_room_size: Label = %LblReverbRoomSize
@onready var lbl_reverb_wet: Label = %LblReverbWet
@onready var lbl_delay_time: Label = %LblDelayTime
@onready var lbl_delay_feedback: Label = %LblDelayFeedback
@onready var lbl_panner_pan: Label = %LblPannerPan
@onready var lbl_pitch_scale: Label = %LblPitchScale

@onready var row_high_pass: HBoxContainer = %RowHighPass
@onready var row_low_pass: HBoxContainer = %RowLowPass


var reset_to_custom_enabled: bool = false


func _ready() -> void :
	save_line.hide()
	_connect_signals()

	_update_from_profile()
	reset_to_custom_enabled = false
	_set_to_custom_and_update_labels_from_sliders()
	reset_to_custom_enabled = true

	_refresh_profile_dropdown()
	MicCrustPresets.presets_changed.connect(_refresh_profile_dropdown)


func _refresh_profile_dropdown() -> void :
	option_crust_profiles.clear()
	for preset_name: String in MicCrustPresets.get_preset_names(): option_crust_profiles.add_item(preset_name)


func _on_option_crust_profiles_item_selected(index: int) -> void :
	MicCrustPresets.apply_preset(option_crust_profiles.get_item_text(index))
	_update_from_profile()
	_set_to_custom_and_update_labels_from_sliders()


func _on_btn_open_save_button_clicked() -> void :
	save_line.visible = !save_line.visible


func _on_line_crust_profile_name_text_changed(new_text: String) -> void :
	btn_save.enable( !new_text.strip_edges().is_empty())


func _save_current_crust() -> void :
	MicCrustPresets.save_current_as(line_crust_profile_name.text)
	line_crust_profile_name.text = ""
	btn_save.enable(false)


func _connect_signals() -> void :
	chk_compressor.toggled.connect(Profile._set_mic_crust_compressor_on)
	chk_limiter.toggled.connect(Profile._set_mic_crust_limiter_on)
	chk_cutoff.toggled.connect(Profile._set_mic_crust_cutoff_on)
	chk_distortion.toggled.connect(Profile._set_mic_crust_distortion_on)
	chk_sample_rate.toggled.connect(Profile._set_mic_crust_sample_rate_on)
	slider_compressor_threshold.value_changed.connect(Profile._set_mic_crust_compressor_threshold)
	slider_compressor_gain.value_changed.connect(Profile._set_mic_crust_compressor_gain)
	slider_limiter_ceiling.value_changed.connect(Profile._set_mic_crust_limiter_ceilingdb)
	slider_limiter_threshold.value_changed.connect(Profile._set_mic_crust_limiter_thresholddb)
	slider_cutoff_high_pass.value_changed.connect(Profile._set_mic_crust_cutoff_high_pass)
	slider_cutoff_low_pass.value_changed.connect(Profile._set_mic_crust_cutoff_low_pass)
	slider_distortion_pre_gain.value_changed.connect(Profile._set_mic_crust_distortion_pre_gain)
	slider_distortion_drive.value_changed.connect(Profile._set_mic_crust_distortion_drive)
	slider_distortion_post_gain.value_changed.connect(Profile._set_mic_crust_distortion_post_gain)
	slider_sample_rate_index.value_changed.connect(Profile._set_mic_crust_sample_rate_index)
	slider_mic_input_volume.value_changed.connect(Profile._set_mic_crust_mic_input)
	slider_mic_multiplier.value_changed.connect(Profile._set_mic_crust_mic_multiplier)
	chk_reverb.toggled.connect(Profile._set_mic_crust_reverb_on)
	slider_reverb_room_size.value_changed.connect(Profile._set_mic_crust_reverb_room_size)
	slider_reverb_wet.value_changed.connect(Profile._set_mic_crust_reverb_wet)
	chk_delay.toggled.connect(Profile._set_mic_crust_delay_on)
	slider_delay_time.value_changed.connect(Profile._set_mic_crust_delay_time_ms)
	slider_delay_feedback.value_changed.connect(Profile._set_mic_crust_delay_feedback_db)
	chk_panner.toggled.connect(Profile._set_mic_crust_panner_on)
	slider_panner_pan.value_changed.connect(Profile._set_mic_crust_panner_pan)
	chk_pitch.toggled.connect(Profile._set_mic_crust_pitch_on)
	slider_pitch_scale.value_changed.connect(Profile._set_mic_crust_pitch_scale)

	chk_compressor.toggled.connect(_set_to_custom_and_update_labels_from_sliders)
	chk_limiter.toggled.connect(_set_to_custom_and_update_labels_from_sliders)
	chk_cutoff.toggled.connect(_set_to_custom_and_update_labels_from_sliders)
	chk_distortion.toggled.connect(_set_to_custom_and_update_labels_from_sliders)
	chk_sample_rate.toggled.connect(_set_to_custom_and_update_labels_from_sliders)
	slider_compressor_threshold.value_changed.connect(_set_to_custom_and_update_labels_from_sliders)
	slider_compressor_gain.value_changed.connect(_set_to_custom_and_update_labels_from_sliders)
	slider_limiter_ceiling.value_changed.connect(_set_to_custom_and_update_labels_from_sliders)
	slider_limiter_threshold.value_changed.connect(_set_to_custom_and_update_labels_from_sliders)
	slider_cutoff_high_pass.value_changed.connect(_set_to_custom_and_update_labels_from_sliders)
	slider_cutoff_low_pass.value_changed.connect(_set_to_custom_and_update_labels_from_sliders)
	slider_distortion_pre_gain.value_changed.connect(_set_to_custom_and_update_labels_from_sliders)
	slider_distortion_drive.value_changed.connect(_set_to_custom_and_update_labels_from_sliders)
	slider_distortion_post_gain.value_changed.connect(_set_to_custom_and_update_labels_from_sliders)
	slider_sample_rate_index.value_changed.connect(_set_to_custom_and_update_labels_from_sliders)
	slider_mic_input_volume.value_changed.connect(_set_to_custom_and_update_labels_from_sliders)
	slider_mic_multiplier.value_changed.connect(_set_to_custom_and_update_labels_from_sliders)
	chk_reverb.toggled.connect(_set_to_custom_and_update_labels_from_sliders)
	slider_reverb_room_size.value_changed.connect(_set_to_custom_and_update_labels_from_sliders)
	slider_reverb_wet.value_changed.connect(_set_to_custom_and_update_labels_from_sliders)
	chk_delay.toggled.connect(_set_to_custom_and_update_labels_from_sliders)
	slider_delay_time.value_changed.connect(_set_to_custom_and_update_labels_from_sliders)
	slider_delay_feedback.value_changed.connect(_set_to_custom_and_update_labels_from_sliders)
	chk_panner.toggled.connect(_set_to_custom_and_update_labels_from_sliders)
	slider_panner_pan.value_changed.connect(_set_to_custom_and_update_labels_from_sliders)
	chk_pitch.toggled.connect(_set_to_custom_and_update_labels_from_sliders)
	slider_pitch_scale.value_changed.connect(_set_to_custom_and_update_labels_from_sliders)


func _update_from_profile() -> void :
	reset_to_custom_enabled = false
	chk_compressor.button_pressed = Profile.mic_crust_compressor_on
	chk_limiter.button_pressed = Profile.mic_crust_limiter_on
	chk_cutoff.button_pressed = Profile.mic_crust_cutoff_on
	chk_distortion.button_pressed = Profile.mic_crust_distortion_on
	chk_sample_rate.button_pressed = Profile.mic_crust_sample_rate_on
	slider_compressor_threshold.value = Profile.mic_crust_compressor_threshold
	slider_compressor_gain.value = Profile.mic_crust_compressor_gain
	slider_limiter_ceiling.value = Profile.mic_crust_limiter_ceilingdb
	slider_limiter_threshold.value = Profile.mic_crust_limiter_thresholddb
	slider_cutoff_high_pass.value = Profile.mic_crust_cutoff_high_pass
	slider_cutoff_low_pass.value = Profile.mic_crust_cutoff_low_pass
	slider_distortion_pre_gain.value = Profile.mic_crust_distortion_pre_gain
	slider_distortion_drive.value = Profile.mic_crust_distortion_drive
	slider_distortion_post_gain.value = Profile.mic_crust_distortion_post_gain
	slider_sample_rate_index.value = Profile.mic_crust_sample_rate_index
	slider_mic_input_volume.value = Profile.mic_crust_mic_input
	slider_mic_multiplier.value = Profile.mic_crust_mic_multiplier
	chk_reverb.button_pressed = Profile.mic_crust_reverb_on
	slider_reverb_room_size.value = Profile.mic_crust_reverb_room_size
	slider_reverb_wet.value = Profile.mic_crust_reverb_wet
	chk_delay.button_pressed = Profile.mic_crust_delay_on
	slider_delay_time.value = Profile.mic_crust_delay_time_ms
	slider_delay_feedback.value = Profile.mic_crust_delay_feedback_db
	chk_panner.button_pressed = Profile.mic_crust_panner_on
	slider_panner_pan.value = Profile.mic_crust_panner_pan
	chk_pitch.button_pressed = Profile.mic_crust_pitch_on
	slider_pitch_scale.value = Profile.mic_crust_pitch_scale
	reset_to_custom_enabled = true


func _set_to_custom_and_update_labels_from_sliders(_dummy: Variant = null) -> void :

	lbl_compressor_threshold.text = "%1.1f dB" % slider_compressor_threshold.value
	lbl_compressor_gain.text = "%1.1f" % slider_compressor_gain.value
	lbl_cutoff_high_pass.text = "%s Hz" % slider_cutoff_high_pass.value
	lbl_cutoff_low_pass.text = "%s Hz" % slider_cutoff_low_pass.value
	lbl_distortion_pre_gain.text = "%1.1f dB" % slider_distortion_pre_gain.value
	lbl_distortion_drive.text = "%s" % slider_distortion_drive.value
	lbl_distortion_post_gain.text = "%1.1f dB" % slider_distortion_post_gain.value
	lbl_limiter_ceiling.text = "%1.1f dB" % slider_limiter_ceiling.value
	lbl_limiter_threshold.text = "%1.1f dB" % slider_limiter_threshold.value
	lbl_sample_rate_reduction.text = "1/%1.0f" % pow(2.0, slider_sample_rate_index.value)
	if slider_cutoff_high_pass.value >= slider_cutoff_low_pass.value:
		if row_high_pass.modulate != Color.FIREBRICK: row_high_pass.modulate = Color.FIREBRICK
		if row_low_pass.modulate != Color.FIREBRICK: row_low_pass.modulate = Color.FIREBRICK
	else:
		if row_high_pass.modulate != Color.WHITE: row_high_pass.modulate = Color.WHITE
		if row_low_pass.modulate != Color.WHITE: row_low_pass.modulate = Color.WHITE
	lbl_mic_input_volume.text = "%1.0f%%" % [slider_mic_input_volume.value * 100.0]
	lbl_mic_multiplier.text = "%1.0fx" % slider_mic_multiplier.value
	lbl_reverb_room_size.text = "%1.2f" % slider_reverb_room_size.value
	lbl_reverb_wet.text = "%1.0f%%" % [slider_reverb_wet.value * 100.0]
	lbl_delay_time.text = "%1.0f ms" % slider_delay_time.value
	lbl_delay_feedback.text = "%1.1f dB" % slider_delay_feedback.value
	if slider_panner_pan.value == 0.0:
		lbl_panner_pan.text = "Center"
	elif slider_panner_pan.value < 0.0:
		lbl_panner_pan.text = "%1.0f%% Left" % [absf(slider_panner_pan.value) * 100.0]
	else:
		lbl_panner_pan.text = "%1.0f%% Right" % [slider_panner_pan.value * 100.0]
	if slider_pitch_scale.value == 1.0:
		lbl_pitch_scale.text = "Normal"
	else:
		lbl_pitch_scale.text = "%1.2fx" % slider_pitch_scale.value
