extends Control









@onready var clip_image: TextureRect = %ClipImage
@onready var clip_audio_player: AudioStreamPlayer = %ClipAudioPlayer
@onready var btn_replay: ButtonCV = %BtnReplay
@onready var lbl_now_recording: Label = %LblNowRecording
@onready var lbl_clip_progress: Label = %LblClipProgress
@onready var list_turn_order: VBoxContainer = %ListTurnOrder
@onready var lbl_paused: Label = %LblPaused
@onready var btn_skip_player: ButtonCV = %BtnSkipPlayer
@onready var btn_back_to_hub: ButtonCV = %BtnBackToHub
@onready var btn_leave: ButtonCV = %BtnLeave
@onready var tex_current_speaker_portrait: TextureRect = %TexCurrentSpeakerPortrait

var _resource: GameplayResourceDubMode
var _current_clip: OmniClip = null


func _ready() -> void :
	_resource = Metro.gameplay_resource_dub_mode

	lbl_paused.hide()
	btn_skip_player.hide()
	btn_back_to_hub.hide()
	btn_skip_player.button_clicked.connect(_on_skip_pressed)
	btn_back_to_hub.button_clicked.connect(_on_back_to_hub_pressed)
	btn_leave.button_clicked.connect(_on_leave_pressed)
	btn_replay.button_clicked.connect(_play_current_clip)




	MultiplayerCharacterSync.character_ready.connect(_on_character_ready)

	MultiplayerGameState.turn_changed.connect(_on_turn_changed)
	MultiplayerGameState.phase_changed.connect(_on_phase_changed)
	MultiplayerLobby.peer_name_resolved.connect( func(_id: int): _refresh_turn_display())

	_refresh_turn_display()
	_show_current_clip()








func _show_current_clip() -> void :
	var clip_index: int = MultiplayerGameState.clip_index
	lbl_clip_progress.text = "Clip %s of %s" % [clip_index + 1, MultiplayerGameState.resolved_clip_order.size()]
	if !_resource or clip_index < 0 or clip_index >= _resource.omni_clip_array.data.size():
		_current_clip = null
		return
	_current_clip = _resource.omni_clip_array.data[clip_index]
	clip_image.texture = _current_clip.clip_texture
	_play_current_clip()


func _play_current_clip() -> void :
	if !_current_clip or !_current_clip.clip_audio: return
	clip_audio_player.stream = _current_clip.clip_audio
	clip_audio_player.play()


func _on_turn_changed(_current_player_id: int) -> void :
	_refresh_turn_display()
	_show_current_clip()


func _on_phase_changed(phase: MultiplayerGameState.PHASE) -> void :
	match phase:
		MultiplayerGameState.PHASE.PAUSED:
			lbl_paused.text = "Paused - %s disconnected" % MultiplayerLobby.get_display_name(MultiplayerGameState.paused_for_player_id)
			lbl_paused.show()
			btn_skip_player.visible = MultiplayerGameState.is_host()
		MultiplayerGameState.PHASE.PLAYING:
			lbl_paused.hide()
			btn_skip_player.hide()





func _refresh_speaker_portrait(current_id: int) -> void :
	var texture: ImageTexture = MultiplayerCharacterSync.get_character_texture(current_id)
	tex_current_speaker_portrait.texture = texture
	tex_current_speaker_portrait.visible = texture != null


func _on_character_ready(peer_id: int, texture: ImageTexture) -> void :
	if peer_id == MultiplayerGameState.current_player_id():
		tex_current_speaker_portrait.texture = texture
		tex_current_speaker_portrait.visible = true


func _on_skip_pressed() -> void :
	if MultiplayerGameState.is_host(): MultiplayerGameState.host_skip_current_player()




func _on_back_to_hub_pressed() -> void :
	MultiplayerGameState.set_my_status(MultiplayerGameState.PLAYER_STATUS.IN_HUB)
	M.world.return_to_menu_slide("res://scenes/nav_specific/multiplayer/multiplayer_lobby_screen.tscn")


func _on_leave_pressed() -> void :
	MultiplayerLobby.leave_lobby()
	MultiplayerGameState.reset()
	M.SaveData()





	M.world.return_to_menu_slide("res://scenes/nav_specific/play_flow/select_member_count.tscn")


func _refresh_turn_display() -> void :
	var current_id: int = MultiplayerGameState.current_player_id()
	if current_id == MultiplayerLobby.my_peer_id:
		lbl_now_recording.text = "Your turn!"
	else:
		lbl_now_recording.text = "%s is recording..." % MultiplayerLobby.get_display_name(current_id)
	_refresh_speaker_portrait(current_id)

	for child: Node in list_turn_order.get_children(): child.queue_free()




	var ids: Array[int] = MultiplayerLobby.connected_player_ids.duplicate()
	ids.sort()
	for peer_id: int in ids:
		var row: Label = Label.new()
		var marker: String = "> " if peer_id == current_id else "   "
		var you: String = " (you)" if peer_id == MultiplayerLobby.my_peer_id else ""
		row.text = "%s%s%s" % [marker, MultiplayerLobby.get_display_name(peer_id), you]
		row.add_theme_color_override("font_color", Color.WHITE if peer_id == current_id else Color(0.7, 0.7, 0.7))
		row.add_theme_color_override("font_outline_color", Color.BLACK)
		row.add_theme_constant_override("outline_size", 4)
		list_turn_order.add_child(row)
