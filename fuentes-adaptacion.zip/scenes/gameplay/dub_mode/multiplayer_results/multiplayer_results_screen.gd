extends Control








@onready var video_player: VideoStreamPlayer = %VideoPlayer
@onready var backing_track_player: AudioStreamPlayer = %BackingTrackPlayer
@onready var replay_streams: Node = %ReplayStreams
@onready var btn_play: ButtonCV = %BtnPlay
@onready var btn_save: ButtonCV = %BtnSave
@onready var btn_back_to_hub: ButtonCV = %BtnBackToHub
@onready var lbl_status: Label = %LblStatus
@onready var lbl_title: Label = %Title

const DUB_RECORD_PREFIX: String = "_dubrecord_"
const TAKE_WAIT_TIMEOUT_SEC: float = 30.0

var _resource: GameplayResourceDubMode
var _performance_array: Array[OmniClipMemberInstance] = []
var _unperformance_array: Array[OmniClipMemberInstance] = []
var _wait_timed_out: bool = false


func _ready() -> void :
	_resource = Metro.gameplay_resource_dub_mode
	if _resource and _resource.pack_info and !_resource.pack_info.display_name.is_empty():
		lbl_title.text = _resource.pack_info.display_name
	btn_play.visible = MultiplayerGameState.is_host()
	btn_play.button_clicked.connect(_on_play_pressed)
	btn_save.button_clicked.connect(_on_save_pressed)
	btn_back_to_hub.button_clicked.connect(_on_back_to_hub_pressed)
	MultiplayerGameState.watch_playback_started.connect(_play_now)
	MultiplayerGameState.everyone_return_to_hub.connect(_actually_return_to_hub)
	MultiplayerTakeSync.take_received.connect(_on_take_received)
	MultiplayerGameState.set_my_status(MultiplayerGameState.PLAYER_STATUS.WATCHING_RESULTS)

	_build_performance_arrays()
	MultiplayerTakeSync.load_all_takes_into(_performance_array)
	_refresh_status()
	if !MultiplayerTakeSync.has_all_takes():











		get_tree().create_timer(TAKE_WAIT_TIMEOUT_SEC).timeout.connect(_on_wait_timeout)


func _build_performance_arrays() -> void :
	if !_resource: return
	for clip: OmniClip in _resource.omni_clip_array.data:
		var instance: OmniClipMemberInstance = OmniClipMemberInstance.new()
		instance.shared_omniclip = clip
		if clip.dub_use_as_is:
			instance.member_audio = clip.clip_audio
			_unperformance_array.append(instance)
		else:
			_performance_array.append(instance)


func _on_take_received(_clip_id: String, _from_peer: int) -> void :
	MultiplayerTakeSync.load_all_takes_into(_performance_array)
	_refresh_status()


func _on_wait_timeout() -> void :
	if MultiplayerTakeSync.has_all_takes(): return
	_wait_timed_out = true
	_refresh_status()


func _refresh_status() -> void :
	if MultiplayerTakeSync.has_all_takes():
		lbl_status.text = "Players synced"
		btn_play.enable(true)
		btn_save.enable(true)
	elif _wait_timed_out:
		lbl_status.text = "Still waiting (%s/%s) - taking a while. You can save what's in, or keep waiting." % [MultiplayerTakeSync.received_count(), MultiplayerTakeSync.expected_count()]
		btn_play.enable(false)
		btn_save.enable(true)
	else:
		lbl_status.text = "Waiting on lines... (%s/%s)" % [MultiplayerTakeSync.received_count(), MultiplayerTakeSync.expected_count()]
		btn_play.enable(false)
		btn_save.enable(false)


func _on_play_pressed() -> void :
	if !MultiplayerGameState.is_host(): return
	MultiplayerGameState.broadcast_watch_started()


func _play_now() -> void :
	for child: Node in replay_streams.get_children(): child.queue_free()

	if _resource and _resource.video: video_player.stream = _resource.video






	video_player.bus = "Mute"
	if _resource and _resource.backing_track: backing_track_player.stream = _resource.backing_track
	video_player.play()
	if backing_track_player.stream and !Profile.dub_mode_mute_backing_track:
		backing_track_player.volume_linear = Profile.dub_mode_backing_track_volume
		backing_track_player.play()






	var performance_fusion: Array[OmniClipMemberInstance] = []
	performance_fusion.append_array(_performance_array)
	performance_fusion.append_array(_unperformance_array)
	for clip: OmniClipMemberInstance in performance_fusion:
		if !clip.member_audio: continue
		var timestamps: PackedFloat32Array = clip.shared_omniclip.dub_timestamps
		if timestamps.is_empty(): timestamps = PackedFloat32Array([0.0])
		for timestamp: float in timestamps:
			var player: AudioStreamPlayer = AudioStreamPlayer.new()
			player.bus = "Pecho"
			player.stream = clip.member_audio
			var timer: Timer = Timer.new()
			timer.one_shot = true
			timer.wait_time = maxf(0.01, timestamp)
			timer.timeout.connect(player.play)
			timer.add_child(player)
			replay_streams.add_child(timer)
	for timer: Timer in replay_streams.get_children(): timer.start()


func _on_back_to_hub_pressed() -> void :


	MultiplayerGameState.broadcast_return_to_hub()


func _actually_return_to_hub() -> void :
	MultiplayerGameState.set_my_status(MultiplayerGameState.PLAYER_STATUS.IN_HUB)
	M.world.return_to_menu_slide("res://scenes/nav_specific/multiplayer/multiplayer_lobby_screen.tscn")






func _on_save_pressed() -> void :
	btn_save.enable(false)
	btn_save.get_child(0).text = "Saving..."
	var unique_recording_name: String = Time.get_datetime_string_from_system().validate_filename()
	if !MultiplayerTakeSync.has_all_takes():




		unique_recording_name += "_INCOMPLETE_%s-of-%s" % [MultiplayerTakeSync.received_count(), MultiplayerTakeSync.expected_count()]
	var target_folder: String = "dub_recordings/" + _resource.pack_info.path_from_pack + unique_recording_name + "/"
	DirAccess.make_dir_recursive_absolute(FileManager.RECORDINGS + target_folder)
	var performance_fusion: Array[OmniClipMemberInstance] = []
	performance_fusion.append_array(_performance_array)
	performance_fusion.append_array(_unperformance_array)
	for clip: OmniClipMemberInstance in performance_fusion:
		if clip.member_audio: clip.save_recording(target_folder + DUB_RECORD_PREFIX + clip.shared_omniclip.file_name_agnostic + ".wav")
	btn_save.get_child(0).text = "Saved!"
