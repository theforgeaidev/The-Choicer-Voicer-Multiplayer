extends Node
signal transfer_offered(from_peer: int, folder_id: String, total_bytes: int, file_count: int)
signal transfer_progress(folder_id: String, bytes_done: int, bytes_total: int)
signal transfer_completed(folder_id: String, local_path: String)
signal transfer_failed(folder_id: String, reason: String)
const CHUNK_SIZE: int = 16 * 1024
const CHUNK_SIZE_STEAM: int = 128 * 1024
const WINDOW_BYTES: int = 256 * 1024
const RECEIVE_TIMEOUT_MSEC: int = 60000
const DEBUG_TRANSFER_LOGGING: bool = false
var _send_queue: Array[Dictionary] = []
var _incoming: Dictionary = {}
func _ready() -> void :
	MultiplayerLobby.player_left.connect(_on_peer_left)
	multiplayer.server_disconnected.connect(_clear_all_transfer_state)
func _on_peer_left(peer_id: int) -> void :
	for i: int in range(_send_queue.size() - 1, -1, -1):
		if _send_queue[i]["peer_id"] == peer_id: _send_queue.remove_at(i)
	var cancelled: Array = []
	for folder_id: String in _incoming:
		if int(_incoming[folder_id]["from_peer"]) == peer_id: cancelled.append(folder_id)
	for folder_id: String in cancelled:
		_incoming.erase(folder_id)
		transfer_failed.emit(folder_id, "El jugador se desconecto durante la transferencia.")
func _clear_all_transfer_state() -> void :
	_send_queue.clear()
	_incoming.clear()
func _process(_delta: float) -> void :
	_pump_send_queue()
	var expired: Array = []
	for folder_id: String in _incoming:
		if Time.get_ticks_msec() - int(_incoming[folder_id].get("last_activity", 0)) > RECEIVE_TIMEOUT_MSEC:
			expired.append(folder_id)
	for folder_id: String in expired:
		_incoming.erase(folder_id)
		transfer_failed.emit(folder_id, "La transferencia no recibio datos durante 60 segundos. Vuelve a intentarlo.")
func send_folder(peer_id: int, local_folder_path: String, folder_id: String, dest_root_relative: String) -> void :
	for job: Dictionary in _send_queue:
		if job["peer_id"] == peer_id and job["folder_id"] == folder_id:
			return
	var manifest: Array[Dictionary] = []
	var total_bytes: int = 0
	_collect_files(local_folder_path, "", manifest)
	for entry: Dictionary in manifest: total_bytes += int(entry["size"])
	_receive_manifest.rpc_id(peer_id, folder_id, dest_root_relative, manifest, total_bytes)
	var files: Array[Dictionary] = []
	for entry: Dictionary in manifest:
		files.append({"rel_path": entry["rel_path"], "abs_path": local_folder_path.path_join(entry["rel_path"]), "size": entry["size"]})
	_send_queue.append({"peer_id": peer_id, "folder_id": folder_id, "files": files, "file_index": 0, "byte_offset": 0, "bytes_sent": 0, "bytes_acked": 0})
func _collect_files(base_path: String, rel_prefix: String, out_manifest: Array[Dictionary]) -> void :
	var dir: DirAccess = DirAccess.open(base_path.path_join(rel_prefix))
	if !dir: return
	dir.list_dir_begin()
	var entry_name: String = dir.get_next()
	while entry_name != "":
		if entry_name in [".", ".."] or entry_name.ends_with(".import"):
			entry_name = dir.get_next()
			continue
		var rel_path: String = rel_prefix.path_join(entry_name) if !rel_prefix.is_empty() else entry_name
		if dir.current_is_dir():
			_collect_files(base_path, rel_path, out_manifest)
		else:
			var source_file: FileAccess = FileAccess.open(base_path.path_join(rel_path), FileAccess.READ)
			if !source_file:
				entry_name = dir.get_next()
				continue
			var size: int = source_file.get_length()
			source_file.close()
			out_manifest.append({"rel_path": rel_path, "size": size})
		entry_name = dir.get_next()
	dir.list_dir_end()
	out_manifest.sort_custom( func(a: Dictionary, b: Dictionary) -> bool: return a["rel_path"] < b["rel_path"])
func compute_folder_hash(folder_path: String) -> String:
	if !DirAccess.dir_exists_absolute(folder_path): return ""
	var manifest: Array[Dictionary] = []
	_collect_files(folder_path, "", manifest)
	var ctx: HashingContext = HashingContext.new()
	ctx.start(HashingContext.HASH_SHA256)
	for entry: Dictionary in manifest:
		ctx.update((entry["rel_path"] as String).to_utf8_buffer())
		var source_file: FileAccess = FileAccess.open(folder_path.path_join(entry["rel_path"]), FileAccess.READ)
		if !source_file: return ""
		while source_file.get_position() < source_file.get_length():
			var block: PackedByteArray = source_file.get_buffer(1024 * 1024)
			if block.is_empty(): return ""
			ctx.update(block)
		source_file.close()
	return ctx.finish().hex_encode()
func does_local_folder_match(folder_path: String, expected_hash: String) -> bool:
	if !DirAccess.dir_exists_absolute(folder_path): return false
	return compute_folder_hash(folder_path) == expected_hash
func _pump_send_queue() -> void :
	if _send_queue.is_empty(): return
	var job: Dictionary = _send_queue[0]
	if !multiplayer.get_peers().has(job["peer_id"]):
		push_warning("MultiplayerFileTransfer | Dropping queued transfer to peer %s - no longer connected." % job["peer_id"])
		_send_queue.pop_front()
		return
	var files: Array = job["files"]
	while true:
		while int(job["file_index"]) < files.size() and int(files[int(job["file_index"])]["size"]) == 0:
			if DEBUG_TRANSFER_LOGGING: print("MultiplayerFileTransfer | SEND skipping empty file_index %s for folder '%s'" % [job["file_index"], job["folder_id"]])
			job["file_index"] = int(job["file_index"]) + 1
			job["byte_offset"] = 0
			job.erase("_cached_bytes")
		if job["file_index"] >= files.size():
			_send_queue.pop_front()
			return
		var unacked: int = int(job.get("bytes_sent", 0)) - int(job.get("bytes_acked", 0))
		if unacked >= WINDOW_BYTES:
			break
		var file_info: Dictionary = files[job["file_index"]]
		var source_file: FileAccess = FileAccess.open(file_info["abs_path"], FileAccess.READ)
		if !source_file or source_file.get_length() != int(file_info["size"]):
			_send_queue.pop_front()
			transfer_failed.emit(job["folder_id"], "El archivo cambio o no se puede leer. Selecciona el pack de nuevo.")
			return
		var offset: int = job["byte_offset"]
		source_file.seek(offset)
		var chunk_size: int = CHUNK_SIZE_STEAM if Engine.has_singleton("Steam") else CHUNK_SIZE
		var chunk: PackedByteArray = source_file.get_buffer(mini(chunk_size, int(file_info["size"]) - offset))
		source_file.close()
		if chunk.is_empty():
			_send_queue.pop_front()
			transfer_failed.emit(job["folder_id"], "No se pudo leer el siguiente bloque del pack.")
			return
		var is_last_chunk: bool = (offset + chunk.size()) >= int(file_info["size"])
		_receive_chunk.rpc_id(job["peer_id"], job["folder_id"], job["file_index"], chunk, is_last_chunk)
		job["bytes_sent"] = int(job.get("bytes_sent", 0)) + chunk.size()
		if is_last_chunk:
			job["file_index"] += 1
			job["byte_offset"] = 0
			job.erase("_cached_bytes")
			if DEBUG_TRANSFER_LOGGING: print("MultiplayerFileTransfer | SEND completed file_index %s for folder '%s' (%s/%s files)" % [job["file_index"] - 1, job["folder_id"], job["file_index"], files.size()])
		else:
			job["byte_offset"] += chunk.size()
	_send_queue[0] = job
@rpc("any_peer", "call_remote", "reliable")
func _on_transfer_ack(folder_id: String, bytes_confirmed: int) -> void :
	var sender_id: int = multiplayer.get_remote_sender_id()
	for i: int in _send_queue.size():
		var job: Dictionary = _send_queue[i]
		if job["peer_id"] == sender_id and job["folder_id"] == folder_id:
			job["bytes_acked"] = bytes_confirmed
			_send_queue[i] = job
			return
@rpc("any_peer", "call_remote", "reliable")
func _receive_manifest(folder_id: String, dest_root_relative: String, manifest: Array, total_bytes: int) -> void :
	if _incoming.has(folder_id):
		return
	var sender_id: int = multiplayer.get_remote_sender_id()
	if !_safe_relative_path(dest_root_relative) or !dest_root_relative.begins_with("game/"):
		transfer_failed.emit(folder_id, "Destino de pack invalido.")
		return
	var typed_manifest: Array[Dictionary] = []
	var declared_total: int = 0
	var seen_paths: Dictionary = {}
	for entry: Variant in manifest:
		if !(entry is Dictionary) or !entry.get("rel_path", null) is String or !entry.get("size", null) is int:
			transfer_failed.emit(folder_id, "Lista de archivos invalida.")
			return
		var relative: String = entry["rel_path"]
		if !_safe_relative_path(relative) or int(entry["size"]) < 0 or seen_paths.has(relative.to_lower()):
			transfer_failed.emit(folder_id, "Nombre o tamano de archivo invalido.")
			return
		seen_paths[relative.to_lower()] = true
		declared_total += int(entry["size"])
		typed_manifest.append(entry)
	if declared_total != total_bytes:
		transfer_failed.emit(folder_id, "El tamano del pack no coincide con sus archivos.")
		return
	_incoming[folder_id] = {
		"dest_root": ("user://" + dest_root_relative), 
		"manifest": typed_manifest, 
		"file_index": 0, 
		"buffer": PackedByteArray(), 
		"bytes_done": 0, 
		"bytes_total": total_bytes, 
		"from_peer": sender_id,
		"last_activity": Time.get_ticks_msec(), 
	}
	_auto_complete_empty_files(folder_id)
	if _incoming.has(folder_id):
		transfer_offered.emit(sender_id, folder_id, total_bytes, typed_manifest.size())
@rpc("any_peer", "call_remote", "reliable")
func _receive_chunk(folder_id: String, file_index: int, chunk: PackedByteArray, is_last_chunk: bool) -> void :
	if !_incoming.has(folder_id):
		return
	var state: Dictionary = _incoming[folder_id]
	if multiplayer.get_remote_sender_id() != int(state["from_peer"]): return
	state["last_activity"] = Time.get_ticks_msec()
	if file_index != state["file_index"]:
		if DEBUG_TRANSFER_LOGGING: print("MultiplayerFileTransfer | DESYNC on folder '%s': got file %s, expected %s (%s bytes already in this file's buffer)" % [folder_id, file_index, state["file_index"], PackedByteArray(state["buffer"]).size()])
		transfer_failed.emit(folder_id, "Received chunk for file %s but expected file %s - transfer desynced." % [file_index, state["file_index"]])
		_incoming.erase(folder_id)
		return
	var buffer: PackedByteArray = state["buffer"]
	var expected_size: int = int(state["manifest"][file_index]["size"])
	if chunk.size() > CHUNK_SIZE_STEAM or buffer.size() + chunk.size() > expected_size or (is_last_chunk and buffer.size() + chunk.size() != expected_size):
		_incoming.erase(folder_id)
		transfer_failed.emit(folder_id, "El archivo recibido esta incompleto o tiene un tamano incorrecto.")
		return
	buffer.append_array(chunk)
	state["buffer"] = buffer
	state["bytes_done"] = int(state["bytes_done"]) + chunk.size()
	transfer_progress.emit(folder_id, state["bytes_done"], state["bytes_total"])
	_on_transfer_ack.rpc_id(state["from_peer"], folder_id, state["bytes_done"])
	if is_last_chunk:
		var manifest: Array[Dictionary] = state["manifest"]
		var rel_path: String = manifest[file_index]["rel_path"]
		var dest_path: String = (state["dest_root"] as String).path_join(rel_path)
		DirAccess.make_dir_recursive_absolute(dest_path.get_base_dir())
		var f: FileAccess = FileAccess.open(dest_path, FileAccess.WRITE)
		if !f:
			transfer_failed.emit(folder_id, "Couldn't write %s (error %s)." % [dest_path, FileAccess.get_open_error()])
			_incoming.erase(folder_id)
			return
		f.store_buffer(buffer)
		f.close()
		state["buffer"] = PackedByteArray()
		state["file_index"] = file_index + 1
		_incoming[folder_id] = state
		if DEBUG_TRANSFER_LOGGING: print("MultiplayerFileTransfer | RECV completed file_index %s for folder '%s' (%s/%s files)" % [file_index, folder_id, state["file_index"], manifest.size()])
		_auto_complete_empty_files(folder_id)
		return
	_incoming[folder_id] = state
func _auto_complete_empty_files(folder_id: String) -> void :
	if !_incoming.has(folder_id): return
	var state: Dictionary = _incoming[folder_id]
	var manifest: Array[Dictionary] = state["manifest"]
	while int(state["file_index"]) < manifest.size() and int(manifest[int(state["file_index"])]["size"]) == 0:
		var idx: int = int(state["file_index"])
		var rel_path: String = manifest[idx]["rel_path"]
		var dest_path: String = (state["dest_root"] as String).path_join(rel_path)
		DirAccess.make_dir_recursive_absolute(dest_path.get_base_dir())
		var f: FileAccess = FileAccess.open(dest_path, FileAccess.WRITE)
		if f: f.close()
		state["file_index"] = idx + 1
		if DEBUG_TRANSFER_LOGGING: print("MultiplayerFileTransfer | RECV auto-completed empty file_index %s for folder '%s'" % [idx, folder_id])
	_incoming[folder_id] = state
	if int(state["file_index"]) >= manifest.size():
		transfer_completed.emit(folder_id, state["dest_root"])
		_incoming.erase(folder_id)

func _safe_relative_path(value: String) -> bool:
	if value.is_empty() or value.is_absolute_path() or value.contains(":") or value.contains("\\"): return false
	for part: String in value.split("/"):
		if part.is_empty() or part == "." or part == ".." or part.ends_with(".") or part.ends_with(" "): return false
	return true
