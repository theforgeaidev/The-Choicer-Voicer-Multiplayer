extends Node


































const CHUNK_SIZE: int = 128 * 1024
const WINDOW_BYTES: int = 256 * 1024
const DEBUG_TAKE_SYNC_LOGGING: bool = true

signal take_received(clip_id: String, from_peer: int)
signal all_expected_takes_received

var _present_clip_ids: Array[String] = []
var _incoming_chunks: Dictionary = {}
var _incoming_totals: Dictionary = {}
var _incoming_complete: Dictionary = {}











var _send_queue: Array[Dictionary] = []


func _ready() -> void :
	MultiplayerLobby.player_left.connect(_on_peer_left)


func _process(_delta: float) -> void :
	_pump_send_queue()


func _pump_send_queue() -> void :
	if _send_queue.is_empty(): return
	var job: Dictionary = _send_queue[0]
	if !multiplayer.get_peers().has(job["peer_id"]):
		_send_queue.pop_front()
		return

	while true:
		if int(job["chunk_index"]) >= int(job["total_chunks"]):
			_send_queue.pop_front()
			return

		var unacked: int = int(job.get("bytes_sent", 0)) - int(job.get("bytes_acked", 0))
		if unacked >= WINDOW_BYTES:
			break

		var bytes: PackedByteArray = job["bytes"]
		var i: int = job["chunk_index"]
		var chunk: PackedByteArray = bytes.slice(i * CHUNK_SIZE, mini((i + 1) * CHUNK_SIZE, bytes.size()))
		_receive_take_chunk.rpc_id(job["peer_id"], job["clip_id"], job["file_type"], i, job["total_chunks"], chunk)
		job["bytes_sent"] = int(job.get("bytes_sent", 0)) + chunk.size()
		job["chunk_index"] = i + 1
		if DEBUG_TAKE_SYNC_LOGGING and job["chunk_index"] >= int(job["total_chunks"]):
			print("MultiplayerTakeSync | SEND completed %s:%s to peer %s" % [job["clip_id"], job["file_type"], job["peer_id"]])

	_send_queue[0] = job


func _on_peer_left(peer_id: int) -> void :
	for i: int in range(_send_queue.size() - 1, -1, -1):
		if _send_queue[i]["peer_id"] == peer_id: _send_queue.remove_at(i)


func _take_storage_dir() -> String:
	return "user://game/multiplayer_takes/%s/" % MultiplayerGameState.selected_pack_hash





func save_and_broadcast_take(member_instance: OmniClipMemberInstance) -> void :
	if !member_instance.member_audio: return
	var clip_id: String = member_instance.shared_omniclip.file_name_agnostic
	_save_take_locally(member_instance, clip_id)
	if !_present_clip_ids.has(clip_id): _present_clip_ids.append(clip_id)

	if MultiplayerLobby.lobby_code.is_empty(): return
	var dir_path: String = _take_storage_dir()
	var wav_bytes: PackedByteArray = FileAccess.get_file_as_bytes(dir_path.path_join(clip_id + ".wav"))
	var score_bytes: PackedByteArray = FileAccess.get_file_as_bytes(dir_path.path_join(clip_id + ".scoredata"))
	for peer_id: int in MultiplayerLobby.connected_player_ids:
		if peer_id != MultiplayerLobby.my_peer_id:
			_queue_send(peer_id, clip_id, "wav", wav_bytes)
			_queue_send(peer_id, clip_id, "scoredata", score_bytes)


func _queue_send(peer_id: int, clip_id: String, file_type: String, bytes: PackedByteArray) -> void :
	var total_chunks: int = maxi(1, ceili(float(bytes.size()) / CHUNK_SIZE))
	_send_queue.append({
		"peer_id": peer_id, "clip_id": clip_id, "file_type": file_type, 
		"bytes": bytes, "total_chunks": total_chunks, "chunk_index": 0, 
		"bytes_sent": 0, "bytes_acked": 0, 
	})


@rpc("any_peer", "call_remote", "reliable")
func _receive_take_chunk(clip_id: String, file_type: String, chunk_index: int, total_chunks: int, chunk: PackedByteArray) -> void :
	var key: String = "%s:%s" % [clip_id, file_type]
	if !_incoming_chunks.has(key): _incoming_chunks[key] = {}
	_incoming_chunks[key][chunk_index] = chunk
	_incoming_totals[key] = total_chunks




	var bytes_so_far: int = 0
	for c: PackedByteArray in _incoming_chunks[key].values(): bytes_so_far += c.size()
	_on_take_chunk_ack.rpc_id(multiplayer.get_remote_sender_id(), clip_id, file_type, bytes_so_far)

	if _incoming_chunks[key].size() < total_chunks: return





	var full_bytes: PackedByteArray = PackedByteArray()
	for i: int in range(total_chunks): full_bytes.append_array(_incoming_chunks[key][i])
	_incoming_chunks.erase(key)
	_incoming_totals.erase(key)
	_write_received_file(clip_id, file_type, full_bytes)


@rpc("any_peer", "call_remote", "reliable")
func _on_take_chunk_ack(clip_id: String, file_type: String, bytes_confirmed: int) -> void :
	var sender_id: int = multiplayer.get_remote_sender_id()
	for i: int in _send_queue.size():
		var job: Dictionary = _send_queue[i]
		if job["peer_id"] == sender_id and job["clip_id"] == clip_id and job["file_type"] == file_type:
			job["bytes_acked"] = bytes_confirmed
			_send_queue[i] = job
			return


func _write_received_file(clip_id: String, file_type: String, bytes: PackedByteArray) -> void :
	var dir_path: String = _take_storage_dir()
	DirAccess.make_dir_recursive_absolute(dir_path)
	var path: String = dir_path.path_join(clip_id + "." + file_type)
	var file: FileAccess = FileAccess.open(path, FileAccess.WRITE)
	if file: file.store_buffer(bytes);file.close()
	else: push_error("MultiplayerTakeSync | Failed to write received %s: error %s" % [path, FileAccess.get_open_error()])

	if !_incoming_complete.has(clip_id): _incoming_complete[clip_id] = {"wav": false, "scoredata": false}
	_incoming_complete[clip_id][file_type] = true


	if _incoming_complete[clip_id].get("wav", false) and _incoming_complete[clip_id].get("scoredata", false):
		_incoming_complete.erase(clip_id)
		if !_present_clip_ids.has(clip_id): _present_clip_ids.append(clip_id)
		take_received.emit(clip_id, multiplayer.get_remote_sender_id())
		if has_all_takes(): all_expected_takes_received.emit()


func has_all_takes() -> bool:
	for clip_id: String in _clip_ids_needing_takes():
		if !_present_clip_ids.has(clip_id): return false
	return true


func received_count() -> int:
	var count: int = 0
	for clip_id: String in _clip_ids_needing_takes():
		if _present_clip_ids.has(clip_id): count += 1
	return count


func expected_count() -> int: return _clip_ids_needing_takes().size()







func _clip_ids_needing_takes() -> Array[String]:
	var needed: Array[String] = []
	var resource: GameplayResourceDubMode = Metro.gameplay_resource_dub_mode
	if !resource:
		needed.assign(MultiplayerGameState.resolved_clip_order)
		return needed
	var use_as_is_ids: Array[String] = []
	for clip: OmniClip in resource.omni_clip_array.data:
		if clip.dub_use_as_is: use_as_is_ids.append(clip.file_name_agnostic)
	for clip_id: String in MultiplayerGameState.resolved_clip_order:
		if !use_as_is_ids.has(clip_id): needed.append(clip_id)
	return needed


func reset() -> void :
	_present_clip_ids.clear()
	_incoming_chunks.clear()
	_incoming_totals.clear()
	_incoming_complete.clear()
	_send_queue.clear()




func _save_take_locally(member_instance: OmniClipMemberInstance, clip_id: String) -> void :
	var dir_path: String = _take_storage_dir()
	DirAccess.make_dir_recursive_absolute(dir_path)
	var base_path: String = dir_path.path_join(clip_id)

	var err: Error = member_instance.member_audio.save_to_wav(base_path + ".wav")
	if err != OK: push_error("MultiplayerTakeSync | Failed to save take to %s.wav: error %s" % [base_path, err])






	var score_file: FileAccess = FileAccess.open(base_path + ".scoredata", FileAccess.WRITE)
	if score_file:
		score_file.store_var(member_instance.data_vclip_average)
		score_file.store_var(member_instance.data_vclip_maximum)
		score_file.store_var(member_instance.data_vclip_pitches)
		score_file.store_var(member_instance.data_plmic_average)
		score_file.store_var(member_instance.data_plmic_maximum)
		score_file.store_var(member_instance.data_plmic_pitches)
		score_file.close()
	else:
		push_error("MultiplayerTakeSync | Failed to save score data for %s: error %s" % [base_path, FileAccess.get_open_error()])





func load_all_takes_into(performance_array: Array) -> void :
	var dir_path: String = _take_storage_dir()
	for clip: OmniClipMemberInstance in performance_array:
		if clip.member_audio: continue
		var base_path: String = dir_path.path_join(clip.shared_omniclip.file_name_agnostic)

		var wav_path: String = base_path + ".wav"
		if FileAccess.file_exists(wav_path):
			var loaded: AudioStreamWAV = _load_wav_file(wav_path)
			if loaded: clip.member_audio = loaded

		var score_path: String = base_path + ".scoredata"
		if FileAccess.file_exists(score_path):
			var score_file: FileAccess = FileAccess.open(score_path, FileAccess.READ)
			if score_file:
				clip.data_vclip_average = score_file.get_var()
				clip.data_vclip_maximum = score_file.get_var()
				clip.data_vclip_pitches = score_file.get_var()
				clip.data_plmic_average = score_file.get_var()
				clip.data_plmic_maximum = score_file.get_var()
				clip.data_plmic_pitches = score_file.get_var()
				score_file.close()


func _load_wav_file(path: String) -> AudioStreamWAV:
	var bytes: PackedByteArray = FileAccess.get_file_as_bytes(path)
	if bytes.size() < 44 or bytes.slice(0, 4).get_string_from_ascii() != "RIFF" or bytes.slice(8, 12).get_string_from_ascii() != "WAVE":
		push_error("MultiplayerTakeSync | %s doesn't look like a valid WAV file." % path)
		return null

	var pos: int = 12
	var channels: int = 1
	var mix_rate: int = 44100
	var bits_per_sample: int = 16
	var data: PackedByteArray = PackedByteArray()
	while pos < bytes.size() - 8:
		var chunk_id: String = bytes.slice(pos, pos + 4).get_string_from_ascii()
		var chunk_size: int = bytes.decode_u32(pos + 4)
		var chunk_start: int = pos + 8
		if chunk_id == "fmt ":
			channels = bytes.decode_u16(chunk_start + 2)
			mix_rate = bytes.decode_u32(chunk_start + 4)
			bits_per_sample = bytes.decode_u16(chunk_start + 14)
		elif chunk_id == "data":
			data = bytes.slice(chunk_start, chunk_start + chunk_size)
		pos = chunk_start + chunk_size + (chunk_size % 2)

	var stream: AudioStreamWAV = AudioStreamWAV.new()
	stream.format = AudioStreamWAV.FORMAT_16_BITS if bits_per_sample == 16 else AudioStreamWAV.FORMAT_8_BITS
	stream.mix_rate = mix_rate
	stream.stereo = (channels == 2)
	stream.data = data
	return stream
