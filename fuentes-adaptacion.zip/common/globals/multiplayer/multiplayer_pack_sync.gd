extends Node










signal verifying_pack
signal transfer_needed(from_peer: int, total_bytes: int)
signal download_confirmation_needed(pack_name: String)
signal transfer_progress(bytes_done: int, bytes_total: int)
signal pack_ready(dub_mode_resource: GameplayResourceDubMode)
signal pack_sync_failed(reason: String)

const _PACK_TRANSFER_ID: String = "dub_mode_pack"
const MAX_AUTO_RETRIES: int = 3

var _pending_folder_relative: String = ""
var _pending_hash: String = ""
var _pending_clip_order: Array[String] = []
var _pack_folder_absolute_for_host: String = ""
var _transfer_request_retry_timer: Timer = null
var _auto_retry_count: int = 0


func _ready() -> void :
	MultiplayerGameState.pack_ready_to_verify.connect(_on_pack_ready_to_verify)
	MultiplayerFileTransfer.transfer_offered.connect(_on_transfer_offered)
	MultiplayerFileTransfer.transfer_progress.connect(_on_transfer_progress)
	MultiplayerFileTransfer.transfer_completed.connect(_on_transfer_completed)
	MultiplayerFileTransfer.transfer_failed.connect(_on_transfer_failed)



	multiplayer.server_disconnected.connect(_on_connection_lost)


func _on_connection_lost() -> void :
	stop_all_retries()
	_pending_folder_relative = ""
	_pending_hash = ""
	_pending_clip_order.clear()





func host_broadcast_pack_selection(dub_mode_resource: GameplayResourceDubMode, pack_folder_absolute: String, pack_folder_relative: String) -> void :
	if !MultiplayerGameState.is_host(): return

	var clip_order: Array[String] = []
	var characters: Array[String] = []
	for clip: OmniClip in dub_mode_resource.omni_clip_array.data:
		clip_order.append(clip.file_name_agnostic)
		for character: String in clip.dub_characters:
			if !characters.has(character): characters.append(character)

	_pack_folder_absolute_for_host = pack_folder_absolute
	var pack_hash: String = MultiplayerFileTransfer.compute_folder_hash(pack_folder_absolute)
	MultiplayerGameState.host_set_selected_pack(pack_folder_relative, pack_hash, clip_order, characters)







	MultiplayerGameState.report_my_pack_status(MultiplayerGameState.PACK_STATUS.READY)






	pack_ready.emit(dub_mode_resource)




func _on_pack_ready_to_verify(pack_folder_relative: String, pack_hash: String, clip_order: Array) -> void :
	if MultiplayerGameState.is_host(): return
	_pending_folder_relative = pack_folder_relative
	_pending_hash = pack_hash
	_pending_clip_order.clear()
	for id: Variant in clip_order: _pending_clip_order.append(str(id))
	_auto_retry_count = 0

	verifying_pack.emit()
	var local_absolute: String = "user://" + pack_folder_relative
	if MultiplayerFileTransfer.does_local_folder_match(local_absolute, pack_hash):
		_finish_with_local_pack(local_absolute)
	else:




		download_confirmation_needed.emit(pack_folder_relative.get_file())



func confirm_download() -> void :
	MultiplayerGameState.report_my_pack_status(MultiplayerGameState.PACK_STATUS.DOWNLOADING)
	_start_transfer_request_retries()




func decline_download() -> void :
	_pending_folder_relative = ""
	_pending_hash = ""
	_pending_clip_order.clear()
	MultiplayerGameState.report_my_pack_status(MultiplayerGameState.PACK_STATUS.REFUSED)
	pack_sync_failed.emit("Download declined - you won't be able to play this pack.")








func _start_transfer_request_retries() -> void :
	_send_transfer_request()
	if _transfer_request_retry_timer: return
	_transfer_request_retry_timer = Timer.new()
	_transfer_request_retry_timer.wait_time = 1.0
	_transfer_request_retry_timer.timeout.connect(_send_transfer_request)
	add_child(_transfer_request_retry_timer)
	_transfer_request_retry_timer.start()


func _send_transfer_request() -> void :
	_request_pack_transfer.rpc_id(1, _pending_folder_relative, _pending_hash)


func _stop_transfer_request_retries() -> void :
	if _transfer_request_retry_timer:
		_transfer_request_retry_timer.stop()
		_transfer_request_retry_timer.queue_free()
		_transfer_request_retry_timer = null





func stop_all_retries() -> void :
	_stop_transfer_request_retries()
	_auto_retry_count = 0


@rpc("any_peer", "call_remote", "reliable")
func _request_pack_transfer(pack_folder_relative: String, pack_hash: String) -> void :
	if !MultiplayerGameState.is_host(): return
	var requesting_peer: int = multiplayer.get_remote_sender_id()
	if pack_folder_relative != MultiplayerGameState.selected_pack_folder_relative or pack_hash != MultiplayerGameState.selected_pack_hash:
		return










	MultiplayerFileTransfer.send_folder(requesting_peer, _pack_folder_absolute_for_host, _PACK_TRANSFER_ID + "_" + pack_hash, pack_folder_relative)


func _on_transfer_offered(_from_peer: int, folder_id: String, total_bytes: int, _file_count: int) -> void :
	if !folder_id.begins_with(_PACK_TRANSFER_ID): return
	_stop_transfer_request_retries()
	transfer_needed.emit(_from_peer, total_bytes)


func _on_transfer_progress(folder_id: String, bytes_done: int, bytes_total: int) -> void :
	if !folder_id.begins_with(_PACK_TRANSFER_ID): return
	transfer_progress.emit(bytes_done, bytes_total)


func _on_transfer_completed(folder_id: String, local_path: String) -> void :
	if !folder_id.begins_with(_PACK_TRANSFER_ID): return






	if !_pending_hash.is_empty() and !MultiplayerFileTransfer.does_local_folder_match(local_path, _pending_hash):
		push_warning("MultiplayerPackSync | Downloaded pack failed hash verification - discarding and retrying.")


		_on_transfer_failed(folder_id, "Downloaded pack didn't match the host's copy (corrupted in transit).")
		return
	_finish_with_local_pack(local_path)







func _delete_folder_recursive(absolute_path: String) -> void :
	var dir: DirAccess = DirAccess.open(absolute_path)
	if !dir: return
	dir.list_dir_begin()
	var entry: String = dir.get_next()
	while entry != "":
		if entry != "." and entry != "..":
			var full: String = absolute_path.path_join(entry)
			if dir.current_is_dir(): _delete_folder_recursive(full)
			else: DirAccess.remove_absolute(full)
		entry = dir.get_next()
	dir.list_dir_end()
	DirAccess.remove_absolute(absolute_path)


func _on_transfer_failed(folder_id: String, reason: String) -> void :
	if !folder_id.begins_with(_PACK_TRANSFER_ID): return












	_auto_retry_count += 1








	if !MultiplayerGameState.is_host() and !_pending_folder_relative.is_empty():
		_delete_folder_recursive("user://" + _pending_folder_relative)
	if _auto_retry_count <= MAX_AUTO_RETRIES:
		pack_sync_failed.emit("%s (retrying, attempt %s/%s...)" % [reason, _auto_retry_count, MAX_AUTO_RETRIES])
		get_tree().create_timer(2.0).timeout.connect(_start_transfer_request_retries)
	else:
		pack_sync_failed.emit("%s - gave up after %s attempts. Try leaving and rejoining the lobby." % [reason, MAX_AUTO_RETRIES])


func _finish_with_local_pack(local_folder_absolute: String) -> void :
	_stop_transfer_request_retries()
	MultiplayerGameState.report_my_pack_status(MultiplayerGameState.PACK_STATUS.READY)
	var folder_path: String = local_folder_absolute
	if !folder_path.ends_with("/"): folder_path += "/"

	var dub_mode_resource: GameplayResourceDubMode = GameplayResourceDubMode.new(folder_path)
	if dub_mode_resource.failed_to_load or dub_mode_resource.no_video_file:
		pack_sync_failed.emit("Pack loaded but appears invalid (missing video or failed to load).")
		return

	var clips_by_id: Dictionary = {}
	for clip: OmniClip in dub_mode_resource.omni_clip_array.data: clips_by_id[clip.file_name_agnostic] = clip

	var ordered: Array[OmniClip] = []
	for clip_id: String in _pending_clip_order:
		if clips_by_id.has(clip_id):
			ordered.append(clips_by_id[clip_id])
		else:
			pack_sync_failed.emit("Pack is missing expected clip '%s' - it may not actually match the host's copy despite the hash check." % clip_id)
			return
	dub_mode_resource.omni_clip_array.data = ordered

	pack_ready.emit(dub_mode_resource)
