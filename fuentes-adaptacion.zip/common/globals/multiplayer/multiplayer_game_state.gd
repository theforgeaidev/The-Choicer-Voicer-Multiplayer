extends Node




























enum PHASE{HUB, PLAYING, PAUSED}
enum PLAYER_STATUS{IN_HUB, PLAYING_OR_SPECTATING, WATCHING_RESULTS}

signal phase_changed(phase: PHASE)
signal turn_changed(current_player_id: int)
signal pack_ready_to_verify(pack_folder_relative: String, pack_hash: String, clip_order: Array)
signal game_in_progress_notice(pack_name: String, current_clip: int, total_clips: int)
signal clip_started(clip_index: int, started_at_msec: int)
signal watch_playback_started
signal everyone_return_to_hub
signal character_claims_changed
signal player_statuses_changed
signal available_characters_changed

var phase: PHASE = PHASE.HUB



var selected_pack_folder_relative: String = ""
var selected_pack_hash: String = ""
var resolved_clip_order: Array[String] = []
var available_characters: Array[String] = []


var clip_index: int = 0
var character_claims: Dictionary = {}
var chronological_mode: bool = false
var paused_for_player_id: int = -1


var player_statuses: Dictionary = {}




var player_pack_ready: Dictionary = {}
const DISCONNECT_PAUSE_GRACE_SEC: float = 20.0
var _disconnect_pause_peer: int = 0




enum PACK_STATUS{UNKNOWN, DOWNLOADING, READY, REFUSED}


func _ready() -> void :
	MultiplayerLobby.player_left.connect(_on_player_left)
	MultiplayerLobby.player_joined.connect(_on_player_joined)


func _on_player_left(peer_id: int) -> void :
	if is_host():
		player_statuses.erase(peer_id)
		player_pack_ready.erase(peer_id)





		var freed_characters: Array = []
		for character: String in character_claims:
			if character_claims[character] == peer_id: freed_characters.append(character)
		for character: String in freed_characters: character_claims.erase(character)
		if !freed_characters.is_empty(): _sync_character_claims.rpc(character_claims.duplicate())

		if phase == PHASE.PLAYING and peer_id == current_player_id():
			host_pause_for_disconnect(peer_id)
		_broadcast_player_statuses()


func _on_player_joined(peer_id: int) -> void :
	if is_host() and !player_statuses.has(peer_id):
		player_statuses[peer_id] = PLAYER_STATUS.IN_HUB
		_broadcast_player_statuses()
	if !is_host(): return






	if !selected_pack_folder_relative.is_empty() and phase == PHASE.HUB:
		_sync_pack_selection.rpc_id(peer_id, selected_pack_folder_relative, selected_pack_hash, resolved_clip_order.duplicate(), available_characters.duplicate())
		_sync_character_claims.rpc_id(peer_id, character_claims.duplicate())
	_sync_pack_ready.rpc_id(peer_id, player_pack_ready.duplicate())






	if phase != PHASE.HUB:
		_sync_game_in_progress.rpc_id(peer_id, selected_pack_folder_relative.get_file(), clip_index, resolved_clip_order.size())


@rpc("authority", "call_remote", "reliable")
func _sync_game_in_progress(pack_name: String, current_clip: int, total_clips: int) -> void :
	game_in_progress_notice.emit(pack_name, current_clip, total_clips)


func is_host() -> bool: return MultiplayerLobby.my_peer_id == 1





func current_player_id() -> int:
	if clip_index < 0 or clip_index >= resolved_clip_order.size(): return -1
	if chronological_mode: return _chronological_player_for_index(clip_index)
	var character: String = _character_for_clip_index(clip_index)
	if character.is_empty() or !character_claims.has(character):



		return _chronological_player_for_index(clip_index)
	return character_claims[character]


func _chronological_player_for_index(index: int) -> int:
	var ids: Array[int] = MultiplayerLobby.connected_player_ids.duplicate()
	ids.sort()
	if ids.is_empty(): return -1
	return ids[index % ids.size()]


func is_my_turn() -> bool: return current_player_id() == MultiplayerLobby.my_peer_id


func _character_for_clip_index(index: int) -> String:
	var resource: GameplayResourceDubMode = Metro.gameplay_resource_dub_mode
	if !resource or index < 0 or index >= resource.omni_clip_array.data.size(): return ""
	var clip: OmniClip = resource.omni_clip_array.data[index]
	return clip.dub_characters[0] if !clip.dub_characters.is_empty() else ""


func everyone_in_hub() -> bool:
	for peer_id: int in MultiplayerLobby.connected_player_ids:
		if player_statuses.get(peer_id, PLAYER_STATUS.IN_HUB) != PLAYER_STATUS.IN_HUB: return false
	return true







func host_set_selected_pack(pack_folder_relative: String, pack_hash: String, clip_order: Array[String], characters: Array[String]) -> void :
	if !is_host(): return
	selected_pack_folder_relative = pack_folder_relative
	selected_pack_hash = pack_hash
	resolved_clip_order = clip_order
	available_characters = characters
	character_claims.clear()
	_sync_pack_selection.rpc(selected_pack_folder_relative, selected_pack_hash, resolved_clip_order.duplicate(), available_characters.duplicate())


func host_start_round() -> void :
	if !is_host(): return
	if !everyone_in_hub(): return
	if resolved_clip_order.is_empty(): return

	if !chronological_mode:
		var candidates: Array[int] = MultiplayerLobby.connected_player_ids.duplicate()
		if !candidates.is_empty():
			for character: String in available_characters:
				if !character_claims.has(character):
					character_claims[character] = candidates[randi() % candidates.size()]
			_broadcast_character_claims()

	for peer_id: int in MultiplayerLobby.connected_player_ids: player_statuses[peer_id] = PLAYER_STATUS.PLAYING_OR_SPECTATING
	_broadcast_player_statuses()





	_sync_round_state.rpc(PHASE.PLAYING, 0, chronological_mode, -1)


func host_advance_turn() -> void :
	if !is_host(): return
	var new_index: int = clip_index + 1
	var new_phase: PHASE = PHASE.HUB if new_index >= resolved_clip_order.size() else PHASE.PLAYING
	_sync_round_state.rpc(new_phase, new_index, chronological_mode, paused_for_player_id)


func host_skip_current_player() -> void :
	if !is_host(): return
	paused_for_player_id = -1
	host_advance_turn()


func host_pause_for_disconnect(peer_id: int) -> void :
	if !is_host(): return
	_sync_round_state.rpc(PHASE.PAUSED, clip_index, chronological_mode, peer_id)






	_disconnect_pause_peer = peer_id
	get_tree().create_timer(DISCONNECT_PAUSE_GRACE_SEC).timeout.connect(_on_disconnect_pause_expired)


func _on_disconnect_pause_expired() -> void :
	if !is_host(): return
	if phase != PHASE.PAUSED: return
	if MultiplayerLobby.connected_player_ids.has(_disconnect_pause_peer): return
	_disconnect_pause_peer = 0


	host_advance_turn()


func host_set_chronological_mode(on: bool) -> void :
	if !is_host(): return
	_sync_round_state.rpc(phase, clip_index, on, paused_for_player_id)




func claim_character(character: String) -> void :
	if is_host(): _do_claim_character(MultiplayerLobby.my_peer_id, character)
	else: _request_claim_character.rpc_id(1, character)


func unclaim_character(character: String) -> void :
	if is_host(): _do_unclaim_character(character)
	else: _request_unclaim_character.rpc_id(1, character)


@rpc("any_peer", "call_remote", "reliable")
func _request_claim_character(character: String) -> void :
	if !is_host(): return
	_do_claim_character(multiplayer.get_remote_sender_id(), character)


@rpc("any_peer", "call_remote", "reliable")
func _request_unclaim_character(character: String) -> void :
	if !is_host(): return


	var sender_id: int = multiplayer.get_remote_sender_id()
	if character_claims.get(character, -1) != sender_id: return
	_do_unclaim_character(character)


func _do_claim_character(peer_id: int, character: String) -> void :
	if !is_host(): return
	if !available_characters.has(character): return
	if phase != PHASE.HUB: return
	character_claims[character] = peer_id
	_broadcast_character_claims()


func _do_unclaim_character(character: String) -> void :
	if !is_host(): return
	if phase != PHASE.HUB: return
	character_claims.erase(character)
	_broadcast_character_claims()


func _broadcast_character_claims() -> void :
	_sync_character_claims.rpc(character_claims.duplicate())


@rpc("authority", "call_local", "reliable")
func _sync_character_claims(claims: Dictionary) -> void :
	character_claims = claims.duplicate()
	character_claims_changed.emit()




func set_my_status(status: PLAYER_STATUS) -> void :
	if is_host(): _do_set_status(MultiplayerLobby.my_peer_id, status)
	else: _request_set_status.rpc_id(1, status)


@rpc("any_peer", "call_remote", "reliable")
func _request_set_status(status: int) -> void :
	if !is_host(): return
	_do_set_status(multiplayer.get_remote_sender_id(), status)


func _do_set_status(peer_id: int, status: int) -> void :
	if !is_host(): return
	player_statuses[peer_id] = status
	_broadcast_player_statuses()


func _broadcast_player_statuses() -> void :
	_sync_player_statuses.rpc(player_statuses.duplicate())


@rpc("authority", "call_local", "reliable")
func _sync_player_statuses(statuses: Dictionary) -> void :
	player_statuses = statuses.duplicate()
	player_statuses_changed.emit()








func report_my_pack_status(status: PACK_STATUS) -> void :
	if is_host():
		_do_set_pack_ready(MultiplayerLobby.my_peer_id, status)
	else:
		_request_set_pack_ready.rpc_id(1, status)


@rpc("any_peer", "call_remote", "reliable")
func _request_set_pack_ready(status: int) -> void :
	_do_set_pack_ready(multiplayer.get_remote_sender_id(), status)


func _do_set_pack_ready(peer_id: int, status: int) -> void :
	if !is_host(): return
	player_pack_ready[peer_id] = status
	_broadcast_pack_ready()


func _broadcast_pack_ready() -> void :
	_sync_pack_ready.rpc(player_pack_ready.duplicate())


@rpc("authority", "call_local", "reliable")
func _sync_pack_ready(ready_map: Dictionary) -> void :
	player_pack_ready = ready_map.duplicate()
	player_statuses_changed.emit()


func is_pack_ready_for(peer_id: int) -> bool:
	return int(player_pack_ready.get(peer_id, PACK_STATUS.UNKNOWN)) == PACK_STATUS.READY


func get_pack_status(peer_id: int) -> int:
	return int(player_pack_ready.get(peer_id, PACK_STATUS.UNKNOWN))




func request_advance_turn() -> void :
	if is_host(): host_advance_turn()
	else: _request_advance_turn_from_host.rpc_id(1)


@rpc("any_peer", "call_remote", "reliable")
func _request_advance_turn_from_host() -> void :
	if !is_host(): return
	var sender_id: int = multiplayer.get_remote_sender_id()
	if sender_id != current_player_id():
		push_warning("MultiplayerGameState | Peer %s requested turn advance but it's peer %s's turn - ignoring." % [sender_id, current_player_id()])
		return
	host_advance_turn()






func broadcast_clip_started(index: int) -> void :
	if MultiplayerLobby.my_peer_id != current_player_id(): return
	_receive_clip_started.rpc(index, Time.get_ticks_msec())


@rpc("any_peer", "call_local", "reliable")
func _receive_clip_started(index: int, started_at_msec: int) -> void :
	var sender_id: int = multiplayer.get_remote_sender_id()
	if sender_id != 0 and sender_id != current_player_id(): return
	clip_started.emit(index, started_at_msec)






func broadcast_watch_started() -> void :
	if !is_host(): return
	_receive_watch_started.rpc()


@rpc("authority", "call_local", "reliable")
func _receive_watch_started() -> void :
	watch_playback_started.emit()





func broadcast_return_to_hub() -> void :
	_receive_return_to_hub.rpc()


@rpc("any_peer", "call_local", "reliable")
func _receive_return_to_hub() -> void :
	everyone_return_to_hub.emit()




@rpc("authority", "call_local", "reliable")
func _sync_pack_selection(new_pack_folder_relative: String, new_pack_hash: String, new_clip_order: Array, new_characters: Array) -> void :
	selected_pack_folder_relative = new_pack_folder_relative
	selected_pack_hash = new_pack_hash
	resolved_clip_order.clear()
	for clip_id: Variant in new_clip_order: resolved_clip_order.append(str(clip_id))
	available_characters.clear()
	for character: Variant in new_characters: available_characters.append(str(character))
	character_claims.clear()



	if is_host():
		player_pack_ready.clear()
		_broadcast_pack_ready()
	available_characters_changed.emit()
	character_claims_changed.emit()









	if !is_host(): pack_ready_to_verify.emit(selected_pack_folder_relative, selected_pack_hash, resolved_clip_order)


@rpc("authority", "call_local", "reliable")
func _sync_round_state(new_phase: int, new_clip_index: int, new_chronological_mode: bool, new_paused_for: int) -> void :
	var old_phase: PHASE = phase
	var old_clip_index: int = clip_index

	phase = new_phase as PHASE
	clip_index = new_clip_index
	chronological_mode = new_chronological_mode
	paused_for_player_id = new_paused_for

	if old_phase != phase: phase_changed.emit(phase)






	if old_clip_index != clip_index or old_phase != phase: turn_changed.emit(current_player_id())


func reset() -> void :
	phase = PHASE.HUB
	selected_pack_folder_relative = ""
	selected_pack_hash = ""
	resolved_clip_order.clear()
	available_characters.clear()
	clip_index = 0
	character_claims.clear()
	chronological_mode = false
	paused_for_player_id = -1
	player_statuses.clear()
	player_pack_ready.clear()
