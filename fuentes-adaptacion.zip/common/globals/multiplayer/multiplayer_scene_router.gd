extends Node












signal pack_readiness_changed(ready_count: int, total_count: int)

var my_pack_ready: bool = false
var _routing_active: bool = false
var _ready_peer_ids: Array[int] = []
var _ready_report_retry_timer: Timer = null


func _ready() -> void :
	MultiplayerPackSync.pack_ready.connect(_on_pack_ready)
	MultiplayerGameState.turn_changed.connect(_on_turn_changed)
	MultiplayerGameState.phase_changed.connect(_on_phase_changed)
	MultiplayerLobby.host_disconnected.connect(_on_host_disconnected)
	MultiplayerLobby.lobby_joined.connect(_on_lobby_joined_globally)










func _on_lobby_joined_globally(_code: String) -> void :
	if MultiplayerLobby.is_on_lobby_screen: return
	M.world.enter_multiplayer_lobby()







func _on_host_disconnected() -> void :
	_routing_active = false






	_stop_ready_report_retries()
	MultiplayerPackSync.stop_all_retries()










	MultiplayerGameState.reset()
	var overlay: CanvasLayer = CanvasLayer.new()
	overlay.layer = 100
	var bg: ColorRect = ColorRect.new()
	bg.color = Color(0, 0, 0, 0.85)
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	overlay.add_child(bg)
	var label: Label = Label.new()
	label.text = "Host Disconnected"
	label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	label.set_anchors_preset(Control.PRESET_FULL_RECT)
	label.add_theme_color_override("font_color", Color.WHITE)
	label.add_theme_font_size_override("font_size", 48)
	overlay.add_child(label)
	get_tree().root.add_child(overlay)

	await get_tree().create_timer(2.5).timeout
	overlay.queue_free()
	M.world.return_to_menu_slide("res://scenes/nav_specific/play_flow/select_member_count.tscn")


func _on_pack_ready(dub_mode_resource: GameplayResourceDubMode) -> void :
	Metro.gameplay_resource_dub_mode = dub_mode_resource
	my_pack_ready = true

	if MultiplayerGameState.is_host():
		if !_ready_peer_ids.has(MultiplayerLobby.my_peer_id): _ready_peer_ids.append(MultiplayerLobby.my_peer_id)
		pack_readiness_changed.emit(_ready_peer_ids.size(), MultiplayerLobby.connected_player_ids.size())
	else:
		_start_ready_report_retries()



	if MultiplayerGameState.phase == MultiplayerGameState.PHASE.PLAYING:
		_routing_active = true
		_route_to_correct_scene()








func _start_ready_report_retries() -> void :
	_send_ready_report()
	if _ready_report_retry_timer: return
	_ready_report_retry_timer = Timer.new()
	_ready_report_retry_timer.wait_time = 1.0
	_ready_report_retry_timer.timeout.connect(_send_ready_report)
	add_child(_ready_report_retry_timer)
	_ready_report_retry_timer.start()


func _send_ready_report() -> void :
	_report_ready_to_host.rpc_id(1)


func _stop_ready_report_retries() -> void :
	if _ready_report_retry_timer:
		_ready_report_retry_timer.stop()
		_ready_report_retry_timer.queue_free()
		_ready_report_retry_timer = null


@rpc("any_peer", "call_remote", "reliable")
func _report_ready_to_host() -> void :
	if !MultiplayerGameState.is_host(): return
	var sender_id: int = multiplayer.get_remote_sender_id()
	if !_ready_peer_ids.has(sender_id): _ready_peer_ids.append(sender_id)
	pack_readiness_changed.emit(_ready_peer_ids.size(), MultiplayerLobby.connected_player_ids.size())
	_ack_ready_report.rpc_id(sender_id)


@rpc("authority", "call_remote", "reliable")
func _ack_ready_report() -> void :
	_stop_ready_report_retries()




func everyone_pack_ready() -> bool:
	if !MultiplayerGameState.is_host(): return my_pack_ready
	for peer_id: int in MultiplayerLobby.connected_player_ids:
		if !_ready_peer_ids.has(peer_id): return false
	return true


func _on_turn_changed(_current_player_id: int) -> void :
	if !_routing_active: return
	_route_to_correct_scene()


func _on_phase_changed(phase: MultiplayerGameState.PHASE) -> void :
	if phase == MultiplayerGameState.PHASE.PLAYING:
		_routing_active = true
		MultiplayerTakeSync.reset()
		_route_to_correct_scene()
	elif phase == MultiplayerGameState.PHASE.HUB:




		var took_part_in_round: bool = my_pack_ready
		_routing_active = false
		_ready_peer_ids.clear()
		my_pack_ready = false
		_stop_ready_report_retries()












		if took_part_in_round:
			M.world.enter_multiplayer_results()


func _route_to_correct_scene() -> void :
	if MultiplayerGameState.phase != MultiplayerGameState.PHASE.PLAYING: return
	if MultiplayerGameState.is_my_turn():
		M.world.enter_dub_mode()
	else:
		M.world.enter_dub_spectate()
