extends Node











signal character_ready(peer_id: int, texture: ImageTexture)
signal character_sync_failed(peer_id: int, reason: String)

const CHARACTER_TRANSFER_PREFIX: String = "character_portrait"

var _peer_character_folder: Dictionary = {}
var _peer_character_hash: Dictionary = {}
var _peer_character_textures: Dictionary = {}
var _pending_requests: Dictionary = {}


func _ready() -> void :
	MultiplayerFileTransfer.transfer_completed.connect(_on_transfer_completed)
	MultiplayerFileTransfer.transfer_failed.connect(_on_transfer_failed)
	MultiplayerLobby.player_left.connect(_on_peer_left)



func announce_my_character(folder_relative: String) -> void :
	if MultiplayerLobby.lobby_code.is_empty(): return
	var absolute: String = "user://" + folder_relative
	var hash_value: String = MultiplayerFileTransfer.compute_folder_hash(absolute)
	_broadcast_character_selection.rpc(folder_relative, hash_value)


@rpc("any_peer", "call_local", "reliable")
func _broadcast_character_selection(folder_relative: String, hash_value: String) -> void :
	var sender_id: int = multiplayer.get_remote_sender_id()
	if sender_id == 0: sender_id = MultiplayerLobby.my_peer_id
	_peer_character_folder[sender_id] = folder_relative
	_peer_character_hash[sender_id] = hash_value
	_peer_character_textures.erase(sender_id)

	var local_absolute: String = "user://" + folder_relative
	if MultiplayerFileTransfer.does_local_folder_match(local_absolute, hash_value):
		_load_character_texture(sender_id, local_absolute)
		return
	if sender_id == MultiplayerLobby.my_peer_id: return


	var folder_id: String = CHARACTER_TRANSFER_PREFIX + "_" + hash_value
	_pending_requests[folder_id] = {"for_peer": sender_id}
	_request_character_transfer.rpc_id(sender_id, folder_relative, hash_value, folder_id)


@rpc("any_peer", "call_remote", "reliable")
func _request_character_transfer(folder_relative: String, hash_value: String, folder_id: String) -> void :
	var requesting_peer: int = multiplayer.get_remote_sender_id()
	var local_absolute: String = "user://" + folder_relative




	if !MultiplayerFileTransfer.does_local_folder_match(local_absolute, hash_value):
		character_sync_failed.emit(requesting_peer, "Character folder no longer matches on the sending side.")
		return
	MultiplayerFileTransfer.send_folder(requesting_peer, local_absolute, folder_id, folder_relative)


func _on_transfer_completed(folder_id: String, local_path: String) -> void :
	if !folder_id.begins_with(CHARACTER_TRANSFER_PREFIX): return
	if !_pending_requests.has(folder_id): return
	var info: Dictionary = _pending_requests[folder_id]
	_pending_requests.erase(folder_id)
	_load_character_texture(info["for_peer"], local_path)


func _on_transfer_failed(folder_id: String, reason: String) -> void :
	if !folder_id.begins_with(CHARACTER_TRANSFER_PREFIX): return
	if !_pending_requests.has(folder_id): return
	var info: Dictionary = _pending_requests[folder_id]
	_pending_requests.erase(folder_id)
	character_sync_failed.emit(info["for_peer"], reason)


func _load_character_texture(peer_id: int, folder_absolute: String) -> void :
	var dir_path: String = folder_absolute if folder_absolute.ends_with("/") else folder_absolute + "/"





	var dir: DirAccess = DirAccess.open(dir_path)
	if !dir:
		character_sync_failed.emit(peer_id, "Couldn't open character folder after transfer.")
		return
	dir.list_dir_begin()
	var entry: String = dir.get_next()
	var image_path: String = ""
	while entry != "":
		var lower: String = entry.to_lower()
		if lower.ends_with(".png") or lower.ends_with(".jpg") or lower.ends_with(".jpeg"):
			image_path = dir_path.path_join(entry)
			break
		entry = dir.get_next()
	dir.list_dir_end()
	if image_path.is_empty():
		character_sync_failed.emit(peer_id, "No image file found in character folder.")
		return





	var img: Image = Image.load_from_file(image_path)
	if img == null:
		character_sync_failed.emit(peer_id, "Failed to load character image from '%s'." % image_path)
		return
	var texture: ImageTexture = ImageTexture.create_from_image(img)
	_peer_character_textures[peer_id] = texture
	character_ready.emit(peer_id, texture)


func get_character_texture(peer_id: int) -> ImageTexture:
	return _peer_character_textures.get(peer_id, null)


func _on_peer_left(peer_id: int) -> void :
	_peer_character_folder.erase(peer_id)
	_peer_character_hash.erase(peer_id)
	_peer_character_textures.erase(peer_id)
	for key: String in _pending_requests.keys():
		if _pending_requests[key]["for_peer"] == peer_id: _pending_requests.erase(key)
