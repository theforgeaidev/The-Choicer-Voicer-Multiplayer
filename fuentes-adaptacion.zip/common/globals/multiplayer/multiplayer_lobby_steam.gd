extends Node
signal connected_to_signaling_server
signal signaling_server_connection_failed(reason: String)
signal lobby_created(code: String)
signal lobby_joined(code: String)
signal join_lobby_failed(reason: String)
signal player_joined(peer_id: int)
signal player_left(peer_id: int)
signal player_connection_ready(peer_id: int)
signal hosting_failed(reason: String)
signal lobby_code_upgraded(code: String, via_upnp: bool)
signal peer_name_resolved(peer_id: int)
signal peer_avatar_resolved(peer_id: int)
signal host_disconnected
signal chat_log_entry_added(entry: Dictionary)
signal joinable_friend_found(steam_id: int, friend_name: String, lobby_id: int)
signal friend_scan_finished
signal friend_avatar_resolved(steam_id: int)
const MAX_MEMBERS: int = 8
const MOD_LOBBY_TAG: String = "choicer_voicer_mp_051_experimental_1"
const DEBUG_STEAM_LOGGING: bool = false
func _dbg(message: String) -> void :
	if DEBUG_STEAM_LOGGING: print(message)
var my_peer_id: int = -1
var lobby_code: String = ""
var lan_code: String = ""
var is_hosting_via_upnp: bool = false
var connected_player_ids: Array[int] = []
var chat_log_history: Array[Dictionary] = []
var is_on_lobby_screen: bool = false
var _lobby_id: int = 0
var _pending_join_target: int = 0
var _awaiting_first_host_connection: bool = false
var _steam_peer: SteamMultiplayerPeer = null
var _steam_ready: bool = false
var _peer_steam_ids: Dictionary = {}
var _peer_names: Dictionary = {}
var _peer_avatars: Dictionary = {}
func _ready() -> void :
	_init_steam()
	Steam.lobby_created.connect(_on_steam_lobby_created)
	Steam.lobby_joined.connect(_on_steam_lobby_joined)
	Steam.join_requested.connect(_on_steam_join_requested)
	Steam.persona_state_change.connect(_on_persona_state_change)
	Steam.avatar_loaded.connect(_on_avatar_loaded)
	Steam.lobby_data_update.connect(_on_lobby_data_update)
	multiplayer.peer_connected.connect(_on_peer_connected)
	multiplayer.peer_disconnected.connect(_on_peer_disconnected)
	multiplayer.server_disconnected.connect(_on_server_disconnected)
func _process(_delta: float) -> void :
	Steam.run_callbacks()
func _init_steam() -> void :
	var init_result: Dictionary = Steam.steamInitEx()
	if init_result.get("status", 1) != 0:
		_steam_ready = false
		signaling_server_connection_failed.emit("Steam failed to initialize: %s. Make sure the Steam client is running and you're logged in." % init_result.get("verbal", "unknown error"))
		return
	_steam_ready = true
	connected_to_signaling_server.emit()
func host_lobby() -> void :
	if !_steam_ready: _init_steam()
	if !_steam_ready:
		hosting_failed.emit("Steam isn't available - is the Steam client running and are you logged in?")
		return
	MultiplayerGameState.reset()
	Steam.createLobby(Steam.LOBBY_TYPE_PUBLIC, MAX_MEMBERS)
func join_lobby(code: String) -> void :
	if !_steam_ready: _init_steam()
	if !_steam_ready:
		join_lobby_failed.emit("Steam isn't available - is the Steam client running and are you logged in?")
		return
	var target_id: int = _code_to_lobby_id(code)
	if target_id == 0:
		join_lobby_failed.emit("That doesn't look like a valid lobby code.")
		return
	if multiplayer.multiplayer_peer != null:
		multiplayer.multiplayer_peer = null
		_steam_peer = null
	_pending_join_target = target_id
	_dbg("MultiplayerLobbySteam | Calling Steam.joinLobby(%s). My Steam ID: %s" % [target_id, Steam.getSteamID()])
	Steam.joinLobby(target_id)
	get_tree().create_timer(8.0).timeout.connect(_check_join_timeout.bind(target_id))
func _check_join_timeout(target_id: int) -> void :
	if _pending_join_target != target_id: return
	_pending_join_target = 0
	join_lobby_failed.emit("Couldn't reach that lobby. Double check the code, or that it's still open.")
func _lobby_id_to_code(id: int) -> String:
	return str(id)
func _code_to_lobby_id(code: String) -> int:
	code = code.strip_edges()
	if code.is_empty() or !code.is_valid_int(): return 0
	return code.to_int()
func leave_lobby() -> void :
	if _lobby_id != 0:
		Steam.leaveLobby(_lobby_id)
	_reset_state()
func _on_steam_lobby_created(connect_result: int, this_lobby_id: int) -> void :
	if connect_result != 1:
		hosting_failed.emit("Steam couldn't create the lobby (result code %s)." % connect_result)
		return
	_lobby_id = this_lobby_id
	lobby_code = _lobby_id_to_code(_lobby_id)
	lan_code = lobby_code
	is_hosting_via_upnp = true
	_dbg("MultiplayerLobbySteam | Lobby created. id=%s code=%s my Steam ID=%s" % [_lobby_id, lobby_code, Steam.getSteamID()])
	Steam.setLobbyJoinable(_lobby_id, true)
	Steam.setLobbyData(_lobby_id, "name", "%s's Choicer Voicer lobby" % Steam.getPersonaName())
	Steam.setLobbyData(_lobby_id, "mod_tag", MOD_LOBBY_TAG)
	_steam_peer = SteamMultiplayerPeer.new()
	var err: int = _steam_peer.create_host(0)
	if err != OK:
		hosting_failed.emit("Steam P2P host setup failed (error %s)." % err)
		return
	_steam_peer.server_relay = true
	multiplayer.set_multiplayer_peer(_steam_peer)
	my_peer_id = multiplayer.get_unique_id()
	if !connected_player_ids.has(my_peer_id): connected_player_ids.append(my_peer_id)
	_peer_steam_ids[my_peer_id] = Steam.getSteamID()
	_resolve_peer_avatar(my_peer_id, Steam.getSteamID())
	lobby_created.emit(lobby_code)
func _on_steam_lobby_joined(this_lobby_id: int, _permissions: int, _locked: bool, response: int) -> void :
	_dbg("MultiplayerLobbySteam | lobby_joined fired. lobby_id=%s response=%s (success would be %s)" % [this_lobby_id, response, Steam.CHAT_ROOM_ENTER_RESPONSE_SUCCESS])
	if response != Steam.CHAT_ROOM_ENTER_RESPONSE_SUCCESS:
		_pending_join_target = 0
		join_lobby_failed.emit("Couldn't join that lobby (response code %s) - it may be full, closed, or no longer exist." % response)
		return
	if Steam.getLobbyOwner(this_lobby_id) == Steam.getSteamID():
		_lobby_id = this_lobby_id
		return
	if Steam.getLobbyData(this_lobby_id, "mod_tag") != MOD_LOBBY_TAG:
		Steam.leaveLobby(this_lobby_id)
		_reset_state()
		join_lobby_failed.emit("Esta sala usa otra version. Todos deben usar MP Experimental 0.5.1 revision 1.")
		return
	_lobby_id = this_lobby_id
	lobby_code = _lobby_id_to_code(_lobby_id)
	lan_code = lobby_code
	var host_steam_id: int = Steam.getLobbyOwner(_lobby_id)
	_steam_peer = SteamMultiplayerPeer.new()
	var err: int = _steam_peer.create_client(host_steam_id, 0)
	if err != OK:
		_pending_join_target = 0
		join_lobby_failed.emit("Steam P2P connection to host failed (error %s)." % err)
		return
	_steam_peer.server_relay = true
	multiplayer.set_multiplayer_peer(_steam_peer)
	my_peer_id = multiplayer.get_unique_id()
	_pending_join_target = 0
	if !connected_player_ids.has(my_peer_id): connected_player_ids.append(my_peer_id)
	_peer_steam_ids[my_peer_id] = Steam.getSteamID()
	_resolve_peer_avatar(my_peer_id, Steam.getSteamID())
	_awaiting_first_host_connection = true
	get_tree().create_timer(15.0).timeout.connect(_on_peer_connect_wait_timeout)
func _on_peer_connect_wait_timeout() -> void:
	if !_awaiting_first_host_connection: return
	leave_lobby()
	join_lobby_failed.emit("No se pudo conectar con el host en 15 segundos. Comprueba Steam e intenta unirte de nuevo.")


func _on_steam_join_requested(this_lobby_id: int, _friend_id: int) -> void :
	join_lobby(_lobby_id_to_code(this_lobby_id))
func _on_peer_connected(peer_id: int) -> void :
	if !connected_player_ids.has(peer_id): connected_player_ids.append(peer_id)
	_resolve_peer_name(peer_id)
	player_joined.emit(peer_id)
	player_connection_ready.emit(peer_id)
	_log_entry("joined", "%s joined" % get_display_name(peer_id))
	if _awaiting_first_host_connection and peer_id == 1:
		_awaiting_first_host_connection = false
		_dbg("MultiplayerLobbySteam | Real P2P connection to host confirmed via peer_connected. Emitting lobby_joined now.")
		lobby_joined.emit(lobby_code)
	if multiplayer.is_server(): _sync_player_roster.rpc(connected_player_ids)
func _on_peer_disconnected(peer_id: int) -> void :
	connected_player_ids.erase(peer_id)
	player_left.emit(peer_id)
	_log_entry("left", "%s left" % get_display_name(peer_id))
	_peer_steam_ids.erase(peer_id)
	_peer_names.erase(peer_id)
	_peer_avatars.erase(peer_id)
	if multiplayer.is_server(): _sync_player_roster.rpc(connected_player_ids)
@rpc("authority", "call_local", "reliable")
func _sync_player_roster(authoritative_ids: Array) -> void :
	var previous_ids: Array[int] = connected_player_ids.duplicate()
	for id: int in authoritative_ids:
		if !connected_player_ids.has(id):
			connected_player_ids.append(id)
			_resolve_peer_name(id)
			player_joined.emit(id)
	for id: int in previous_ids:
		if !authoritative_ids.has(id):
			connected_player_ids.erase(id)
			player_left.emit(id)
func _on_server_disconnected() -> void :
	host_disconnected.emit()
	_reset_state()
func get_display_name(peer_id: int) -> String:
	if peer_id == my_peer_id: return Steam.getPersonaName()
	if _peer_names.has(peer_id): return _peer_names[peer_id]
	return "Player %s" % peer_id
func _resolve_peer_name(peer_id: int) -> void :
	if !_steam_peer: return
	var steam_id: int = _steam_peer.get_steam_id_for_peer_id(peer_id)
	if steam_id == 0: return
	_peer_steam_ids[peer_id] = steam_id
	var existing_name: String = Steam.getFriendPersonaName(steam_id)
	if !existing_name.is_empty() and existing_name != "[unknown]":
		_peer_names[peer_id] = existing_name
		peer_name_resolved.emit(peer_id)
	else:
		Steam.requestUserInformation(steam_id, true)
	_resolve_peer_avatar(peer_id, steam_id)
func _on_persona_state_change(steam_id: int, _flags: int) -> void :
	for peer_id: int in _peer_steam_ids:
		if _peer_steam_ids[peer_id] == steam_id:
			var name: String = Steam.getFriendPersonaName(steam_id)
			if !name.is_empty() and name != "[unknown]":
				_peer_names[peer_id] = name
				peer_name_resolved.emit(peer_id)
			return
func send_chat_message(message: String) -> void :
	message = message.strip_edges()
	if message.is_empty(): return
	_receive_chat_message.rpc(my_peer_id, message)
@rpc("any_peer", "call_local", "reliable")
func _receive_chat_message(sender_peer_id: int, message: String) -> void :
	var actual_sender: int = multiplayer.get_remote_sender_id()
	if actual_sender != 0: sender_peer_id = actual_sender
	message = message.strip_edges().left(1000)
	if message.is_empty(): return
	_log_entry("chat", "%s: %s" % [get_display_name(sender_peer_id), message])
func _log_entry(type: String, text: String) -> void :
	var entry: Dictionary = {"type": type, "text": text}
	chat_log_history.append(entry)
	if chat_log_history.size() > 200: chat_log_history.pop_front()
	chat_log_entry_added.emit(entry)
func get_avatar_texture(peer_id: int) -> ImageTexture:
	return _peer_avatars.get(peer_id, null)
func _resolve_peer_avatar(_peer_id: int, steam_id: int) -> void :
	Steam.getPlayerAvatar(Steam.AVATAR_MEDIUM, steam_id)
func _on_avatar_loaded(steam_id: int, avatar_size: int, avatar_buffer: PackedByteArray) -> void :
	var size: int = avatar_size
	if size <= 0 or avatar_buffer.size() < size * size * 4:
		size = int(sqrt(float(avatar_buffer.size()) / 4.0))
	if size <= 0 or avatar_buffer.size() < size * size * 4:
		push_warning("MultiplayerLobbySteam | avatar_loaded gave unusable data (size=%s, buffer=%s bytes) - skipping this avatar." % [avatar_size, avatar_buffer.size()])
		return
	for peer_id: int in _peer_steam_ids:
		if _peer_steam_ids[peer_id] == steam_id:
			_try_build_avatar_texture(peer_id, {"ret": true, "avatar_size": size, "buffer": avatar_buffer})
			return
	var img: Image = Image.create_from_data(size, size, false, Image.FORMAT_RGBA8, avatar_buffer)
	if !img: return
	_friend_avatars[steam_id] = ImageTexture.create_from_image(img)
	friend_avatar_resolved.emit(steam_id)
func _try_build_avatar_texture(peer_id: int, data: Variant) -> void :
	if !(data is Dictionary): return
	var d: Dictionary = data
	if !d.get("ret", false): return
	var size: int = d.get("avatar_size", 0)
	var buffer: PackedByteArray = d.get("buffer", PackedByteArray())
	if size <= 0 or buffer.size() < size * size * 4: return
	var img: Image = Image.create_from_data(size, size, false, Image.FORMAT_RGBA8, buffer)
	if !img: return
	_peer_avatars[peer_id] = ImageTexture.create_from_image(img)
	peer_avatar_resolved.emit(peer_id)
var _pending_candidate_lobbies: Dictionary = {}
var _friend_avatars: Dictionary = {}
func get_friend_avatar(steam_id: int) -> ImageTexture:
	return _friend_avatars.get(steam_id, null)
func scan_for_joinable_friends() -> void :
	_pending_candidate_lobbies.clear()
	if !_steam_ready:
		friend_scan_finished.emit()
		return
	var friend_count: int = Steam.getFriendCount(Steam.FRIEND_FLAG_IMMEDIATE)
	_dbg("MultiplayerLobbySteam | Friend scan starting. Friend count: %s" % friend_count)
	for i: int in range(friend_count):
		var friend_id: int = Steam.getFriendByIndex(i, Steam.FRIEND_FLAG_IMMEDIATE)
		var game_info: Dictionary = Steam.getFriendGamePlayed(friend_id)
		var friend_game_id: int = int(game_info.get("id", 0))
		var friend_lobby_id: int = int(game_info.get("lobby", 0))
		if friend_game_id != 480 or friend_lobby_id == 0: continue
		_dbg("MultiplayerLobbySteam | Candidate: %s (lobby %s)" % [Steam.getFriendPersonaName(friend_id), friend_lobby_id])
		_pending_candidate_lobbies[friend_lobby_id] = {"steam_id": friend_id, "name": Steam.getFriendPersonaName(friend_id)}
		Steam.requestLobbyData(friend_lobby_id)
	_dbg("MultiplayerLobbySteam | Friend scan found %s app-480 candidate(s) to verify." % _pending_candidate_lobbies.size())
	if _pending_candidate_lobbies.is_empty():
		friend_scan_finished.emit()
		return
	get_tree().create_timer(3.0).timeout.connect(_on_verification_timeout)
func _on_verification_timeout() -> void :
	if _pending_candidate_lobbies.is_empty(): return
	_dbg("MultiplayerLobbySteam | %s candidate(s) never got lobby data back - showing them anyway (unverified)." % _pending_candidate_lobbies.size())
	for lobby_id: int in _pending_candidate_lobbies:
		var info: Dictionary = _pending_candidate_lobbies[lobby_id]
		Steam.getPlayerAvatar(Steam.AVATAR_MEDIUM, info["steam_id"])
		joinable_friend_found.emit(info["steam_id"], info["name"], lobby_id)
	_pending_candidate_lobbies.clear()
	friend_scan_finished.emit()
func _on_lobby_data_update(_arg1: Variant, _arg2: Variant, _arg3: Variant) -> void :
	var resolved: Array[int] = []
	for lobby_id: int in _pending_candidate_lobbies:
		var tag: String = Steam.getLobbyData(lobby_id, "mod_tag")
		_dbg("MultiplayerLobbySteam | lobby_data_update check - lobby %s mod_tag='%s' (need '%s')" % [lobby_id, tag, MOD_LOBBY_TAG])
		if tag == MOD_LOBBY_TAG:
			var info: Dictionary = _pending_candidate_lobbies[lobby_id]
			Steam.getPlayerAvatar(Steam.AVATAR_MEDIUM, info["steam_id"])
			joinable_friend_found.emit(info["steam_id"], info["name"], lobby_id)
			resolved.append(lobby_id)
		elif !tag.is_empty():
			resolved.append(lobby_id)
	for lobby_id: int in resolved: _pending_candidate_lobbies.erase(lobby_id)
	if _pending_candidate_lobbies.is_empty(): friend_scan_finished.emit()
func _reset_state() -> void :
	if multiplayer.multiplayer_peer == _steam_peer:
		multiplayer.multiplayer_peer = null
	_steam_peer = null
	_lobby_id = 0
	_pending_join_target = 0
	_awaiting_first_host_connection = false
	lobby_code = ""
	lan_code = ""
	is_hosting_via_upnp = false
	connected_player_ids.clear()
	_peer_steam_ids.clear()
	_peer_names.clear()
	_peer_avatars.clear()
	chat_log_history.clear()
