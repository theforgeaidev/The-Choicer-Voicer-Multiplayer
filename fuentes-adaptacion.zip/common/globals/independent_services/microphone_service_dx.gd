extends Node




































































































signal mic_ready
signal mic_off
signal waiting_mic_warmup
signal recording_started
signal recording_ended(record_result: AudioStream)


enum STATE{OFF, WARMUP, ENABLED, RECORDING}


const PRINTSTR: String = "Microphone Service | "

const FIX_VERSION: String = "v7.2"








const PLMIC_EFFECT_RECORD_INDEX: int = 10
const PLMIC_EFFECT_SPECTRUM_INDEX: int = 11
const WARMUP_TIME: float = 1.5



const CAPTURE_BUFFER_WALL_SECONDS: float = 20.0
const CAPTURE_BUFFER_MAX_SECONDS: float = 90.0




const MIX_CHUNK_CANDIDATES: Array[int] = [4096, 2048, 1024, 512, 256, 128]
const MAX_MIX_CHUNK: int = 4096
const DEFAULT_MIX_CHUNK: int = 1024


const PROBE_PERIODS: int = 2


const SIGNAL_FLOOR: float = 0.003


const PENDING_LIMIT_SECONDS: float = 6.0

const LIMIT_KNEE: float = 0.7


const SCAN_STRIDE: int = 4




const CONTRAST_MIN: float = 4.0


const KEEP_TOLERANCE: float = 1.05


var state: STATE = STATE.OFF: set = _set_state


var player: AudioStreamPlayer
var warmup_timer: Timer


var plmic_bus_index: int = AudioServer.get_bus_index("Plmic")
var audio_effect_record: AudioEffectRecord: get = _get_audio_effect_record
var audio_effect_spectrum_analyzer: AudioEffectSpectrumAnalyzerInstance: get = _get_audio_effect_spectrum_analyzer

var _capture: AudioEffectCapture
var _pcm: PackedByteArray = PackedByteArray()
var _pcm_used: int = 0
var _pending: PackedVector2Array = PackedVector2Array()
var _pending_peak: float = 0.0

var _channels: int = 1


var _active: bool = false
var _decided: bool = false
var _mix_chunk_frames: int = DEFAULT_MIX_CHUNK


var _period_blocks: int = 1


var _phase_block: int = 0




var _phase_abs: int = 0
var _consumed: int = 0



var _use_right: bool = false
var _recorded_frames: int = 0
var _discarded_seen: int = 0


var _interleave_locked: bool = false
var _shape_warns: int = 0



func _set_state(value: STATE) -> void :








	if value == state: return
	var state_pair: Array[STATE] = []
	state_pair = [state, value]
	match state_pair:
		[STATE.OFF, STATE.WARMUP]:
			player.play()
			warmup_timer.start()
			state = value;waiting_mic_warmup.emit()
		[STATE.WARMUP, STATE.OFF]:
			player.stop()
			warmup_timer.stop()
			state = value;mic_off.emit()
		[STATE.WARMUP, STATE.ENABLED]:
			if warmup_timer.time_left:
				printerr(PRINTSTR + "Tried leaving warmup without waiting sufficiently long.")
				return
			state = value;mic_ready.emit()
		[STATE.WARMUP, STATE.RECORDING]:
			printerr(PRINTSTR + "Tried recording while still in warmup.")
			waiting_mic_warmup.emit()
		[STATE.ENABLED, STATE.OFF]:
			player.stop()
			state = value;mic_off.emit()
		[STATE.ENABLED, STATE.RECORDING]:
			_begin_capture()
			var rec_on: AudioEffectRecord = audio_effect_record
			if rec_on: rec_on.set_recording_active(true)
			state = value;recording_started.emit()
		[STATE.RECORDING, STATE.OFF]:
			var rec_off: AudioEffectRecord = audio_effect_record
			if rec_off: rec_off.set_recording_active(false)
			var wav: AudioStreamWAV = _finish_capture()
			player.stop()
			mic_off.emit()
			state = value;recording_ended.emit(wav)
		[STATE.RECORDING, STATE.ENABLED]:
			var rec_end: AudioEffectRecord = audio_effect_record
			if rec_end: rec_end.set_recording_active(false)
			var wav2: AudioStreamWAV = _finish_capture()
			state = value;recording_ended.emit(wav2)
		_: printerr(PRINTSTR + "Invalid state change was attmpted, from state `%s` to state `%s`" % [state, value])


func reset() -> void :
	state = STATE.OFF
	await get_tree().process_frame
	state = STATE.WARMUP
func disable() -> void : state = STATE.OFF
func warmup() -> void : state = STATE.WARMUP
func recording_on() -> void : state = STATE.RECORDING
func recording_off() -> void : state = STATE.ENABLED


func get_recording() -> AudioStreamWAV:
	if not _active: return _record_effect_recording()
	if state == STATE.RECORDING:
		_drain_capture()
	if _pcm_used > 0:
		var pcm_live: PackedByteArray = _finished_pcm()
		var live_peak: int = _pcm_peak(pcm_live)
		var live_gain: float = _makeup_gain(live_peak)
		if live_gain > 1.01:
			pcm_live = _scale_pcm(pcm_live, live_gain)
		return _pcm_to_wav(pcm_live)
	return _record_effect_recording()


func _initialize_player() -> void :
	player = AudioStreamPlayer.new()
	player.stream = AudioStreamMicrophone.new()
	player.bus = "Plmic"
	add_child(player)
func _initialize_warmup_timer() -> void :
	warmup_timer = Timer.new()
	warmup_timer.one_shot = true
	warmup_timer.wait_time = WARMUP_TIME

	warmup_timer.timeout.connect(_set_state.bind(STATE.ENABLED))
	add_child(warmup_timer)










func _refresh_bus() -> int:
	if plmic_bus_index < 0 or plmic_bus_index >= AudioServer.bus_count\
	or AudioServer.get_bus_name(plmic_bus_index) != "Plmic":
		plmic_bus_index = AudioServer.get_bus_index("Plmic")
	return plmic_bus_index


func _find_record_effect() -> AudioEffectRecord:
	var bus: int = _refresh_bus()
	if bus < 0: return null
	for i: int in AudioServer.get_bus_effect_count(bus):
		var effect: AudioEffectRecord = AudioServer.get_bus_effect(bus, i) as AudioEffectRecord
		if effect != null: return effect
	return null


func _get_audio_effect_record() -> AudioEffectRecord:
	return _find_record_effect()


func _get_audio_effect_spectrum_analyzer() -> AudioEffectSpectrumAnalyzerInstance:
	var bus: int = _refresh_bus()
	if bus < 0: return null
	for i: int in AudioServer.get_bus_effect_count(bus):
		if AudioServer.get_bus_effect(bus, i) is AudioEffectSpectrumAnalyzer:
			return AudioServer.get_bus_effect_instance(bus, i) as AudioEffectSpectrumAnalyzerInstance


	return AudioServer.get_bus_effect_instance(bus, PLMIC_EFFECT_SPECTRUM_INDEX) as AudioEffectSpectrumAnalyzerInstance


func _record_effect_recording() -> AudioStreamWAV:
	var effect: AudioEffectRecord = _find_record_effect()
	if effect == null: return null
	return effect.get_recording()


func get_enabled() -> bool: return player.playing
func get_is_recording() -> bool:
	var effect: AudioEffectRecord = _find_record_effect()
	return effect != null and effect.is_recording_active()


func _bus_channels() -> int:
	return maxi(1, AudioServer.get_bus_channels(_refresh_bus()))






func _capture_still_on_bus() -> bool:
	var bus: int = _refresh_bus()
	if bus < 0 or _capture == null: return false
	for i: int in AudioServer.get_bus_effect_count(bus):
		if AudioServer.get_bus_effect(bus, i) == _capture: return true
	return false


func _ensure_capture_effect() -> void :
	var bus: int = _refresh_bus()
	if bus < 0: return
	var channels: int = _bus_channels()
	var needed_len: float = minf(CAPTURE_BUFFER_MAX_SECONDS, 
		CAPTURE_BUFFER_WALL_SECONDS * float(channels))


	if _capture != null and _capture_still_on_bus():
		if _capture.buffer_length < needed_len - 0.1:
			_capture.buffer_length = needed_len
		return
	_capture = AudioEffectCapture.new()
	_capture.buffer_length = needed_len
	AudioServer.add_bus_effect(bus, _capture)
	print(PRINTSTR + "%s: AudioEffectCapture on Plmic speaker_mode=%s bus_ch=%d mix_rate=%d buffer=%.1fs" % [
		FIX_VERSION, AudioServer.get_speaker_mode(), channels, int(AudioServer.get_mix_rate()), needed_len])


func _discarded() -> int:
	if _capture == null: return 0
	if not _capture.has_method("get_discarded_frames"): return 0
	return int(_capture.call("get_discarded_frames"))


func _begin_capture() -> void :
	_channels = _bus_channels()



	_active = _channels > 1
	_pcm = PackedByteArray()
	_pcm_used = 0
	_pending = PackedVector2Array()
	_pending_peak = 0.0
	_recorded_frames = 0
	_decided = false
	_mix_chunk_frames = DEFAULT_MIX_CHUNK
	_period_blocks = 1
	_phase_block = 0
	_phase_abs = 0
	_consumed = 0
	_use_right = false
	_channel_mode = 0
	_interleave_locked = false
	_shape_warns = 0
	if not _active:
		print(PRINTSTR + "bus has one channel (no surround), leaving the game's own recorder in charge")
		return
	_ensure_capture_effect()
	if _capture:
		_capture.clear_buffer()
		_discarded_seen = _discarded()


func _finish_capture() -> AudioStreamWAV:
	if not _active:
		return _record_effect_recording()
	_drain_capture()




	if _capture:
		var rest: int = _capture.get_frames_available()
		if rest > 0: _pending.append_array(_capture.get_buffer(rest))
	if _pending.size() > 0:
		if not _decided:
			if _peak_of(_pending) >= SIGNAL_FLOOR:
				_decide_from(_pending)
			else:


				_apply_multichannel_default("no clear signal in this take")
		_emit(_pending, true)
		_pending = PackedVector2Array()

	var pcm_bytes: PackedByteArray = _finished_pcm()
	var raw_peak: int = _pcm_peak(pcm_bytes)
	var gain: float = _makeup_gain(raw_peak)
	if gain > 1.01:
		pcm_bytes = _scale_pcm(pcm_bytes, gain)
	var from_capture: AudioStreamWAV = _pcm_to_wav(pcm_bytes)
	var from_record: AudioStreamWAV = _record_effect_recording()
	var capture_peak: int = _pcm_peak(from_capture.data)
	var record_peak: int = _wav_peak(from_record)
	var secs: float = float(_recorded_frames) / maxf(1.0, AudioServer.get_mix_rate())
	var ch_label: String = ["L", "R", "LR"][_channel_mode] if _channel_mode >= 0 and _channel_mode <= 2 else "?"
	print(PRINTSTR + "capture_peak=%d (raw=%d gain=%.2f) record_peak=%d frames=%d secs=%.2f channels=%d chunk=%d phase=%d ch=%s mix_rate=%d" % [
		capture_peak, raw_peak, gain, record_peak, _recorded_frames, secs, _channels, 
		_mix_chunk_frames, _phase_block, ch_label, 
		int(AudioServer.get_mix_rate())])

	if capture_peak > 50: return from_capture
	if record_peak > 50: return from_record
	if from_capture.data.size() > 0: return from_capture
	return from_record


func _process(_delta: float) -> void :
	if state == STATE.RECORDING:
		_drain_capture()


func _drain_capture() -> void :
	if not _active or _capture == null: return




	var dropped: int = _discarded()
	if dropped > _discarded_seen:
		printerr(PRINTSTR + "capture ring dropped %d frames; realigning" % (dropped - _discarded_seen))
		_discarded_seen = dropped
		_decided = false
		_pending = PackedVector2Array()
		_pending_peak = 0.0

	var available: int = _capture.get_frames_available()
	if available <= 0: return

	if _decided:
		var period: int = _mix_chunk_frames * _period_blocks
		var take: int = available - (available % period)
		if take <= 0: return
		var frames: PackedVector2Array = _capture.get_buffer(take)



		if _period_blocks > 1 and not _shape_still_holds(frames):



			_shape_warns += 1
			if _shape_warns <= 3:
				printerr(PRINTSTR + "shape check soft-fail (kept locked alignment chunk=%d blocks=%d phase=%d)" % [
					_mix_chunk_frames, _period_blocks, _phase_block])
		_emit(frames)
		return





	var probe_frames: int = MAX_MIX_CHUNK * maxi(2, _channels) * PROBE_PERIODS
	if available < probe_frames: return

	var block: PackedVector2Array = _capture.get_buffer(probe_frames)
	_pending.append_array(block)
	_pending_peak = maxf(_pending_peak, _peak_of(block))

	if _pending_peak < SIGNAL_FLOOR:
		var held: int = int(PENDING_LIMIT_SECONDS * AudioServer.get_mix_rate()) * _channels
		if _pending.size() >= held:
			_apply_multichannel_default("still silent after %.0fs" % PENDING_LIMIT_SECONDS)
			_emit(_pending)
			_pending = PackedVector2Array()
		return

	_decide_from(_pending)
	_emit(_pending)
	_pending = PackedVector2Array()




func _apply_multichannel_default(reason: String) -> void :
	_mix_chunk_frames = DEFAULT_MIX_CHUNK
	if _channels > 1:
		_period_blocks = _channels
		_phase_block = 0
		_interleave_locked = true
		print(PRINTSTR + "%s; defaulting to 1-of-%d bus channels" % [reason, _period_blocks])
	else:
		_period_blocks = 1
		_phase_block = 0
		print(PRINTSTR + "%s; keeping every frame" % reason)
	_phase_abs = _consumed + _phase_block * _mix_chunk_frames
	_decided = true




func _peak_of(frames: PackedVector2Array) -> float:
	var peak: float = 0.0
	var i: int = 0
	while i < frames.size():
		var f: Vector2 = frames[i]
		peak = maxf(peak, maxf(absf(f.x), absf(f.y)))
		i += SCAN_STRIDE
	return peak







func _decide_from(frames: PackedVector2Array) -> void :











	var found_chunk: int = 0
	var found_blocks: int = 1
	var found_phase: int = 0
	var found_score: float = 0.0
	var found_kept: float = 0.0
	var loose_score: float = 0.0

	for chunk: int in MIX_CHUNK_CANDIDATES:
		for blocks: int in range(2, _channels + 1):
			var period: int = chunk * blocks
			if frames.size() < period * 2: continue
			var periods: int = frames.size() / period

			var energy: PackedFloat32Array = PackedFloat32Array()
			energy.resize(blocks)
			for pi: int in periods:
				for b: int in blocks:
					var base: int = pi * period + b * chunk
					var sum: float = 0.0
					var j: int = 0
					while j < chunk:
						var f: Vector2 = frames[base + j]
						sum += absf(f.x) + absf(f.y)
						j += SCAN_STRIDE
					energy[b] += sum

			var total: float = 0.0
			for b: int in blocks: total += energy[b]
			if total <= 0.0: continue
			for b: int in blocks:
				var others: float = (total - energy[b]) / float(blocks - 1)
				var score: float = energy[b] / maxf(1e-06, others)
				loose_score = maxf(loose_score, score)
				if score < CONTRAST_MIN: continue






				var kept: float = energy[b] - others
				var better: bool = false
				if found_chunk == 0:
					better = true
				elif kept > found_kept * KEEP_TOLERANCE:

					better = true
				elif kept * KEEP_TOLERANCE >= found_kept:







					if blocks > found_blocks:
						better = true
					elif blocks == found_blocks and chunk < found_chunk:
						better = true
					elif blocks == found_blocks and chunk == found_chunk and score > found_score:
						better = true
				if better:
					found_chunk = chunk
					found_blocks = blocks
					found_phase = b
					found_score = score
					found_kept = kept




	if found_chunk == 0:
		if _interleave_locked and _period_blocks > 1:

			print(PRINTSTR + "weak contrast %.1f; keeping locked interleave chunk=%d blocks=%d phase=%d" % [
				loose_score, _mix_chunk_frames, _period_blocks, _phase_block])
		elif _channels > 1:


			_mix_chunk_frames = DEFAULT_MIX_CHUNK
			_period_blocks = _channels
			_phase_block = _loudest_block(frames, _mix_chunk_frames, _period_blocks)
			_interleave_locked = true
			print(PRINTSTR + "no clear padding (contrast %.1f); defaulting to 1-of-%d bus channels (phase %d)" % [
				loose_score, _period_blocks, _phase_block])
		else:
			_mix_chunk_frames = DEFAULT_MIX_CHUNK
			_period_blocks = 1
			_phase_block = 0
			print(PRINTSTR + "no convincing padding (best contrast %.1f); keeping every frame" % loose_score)
	else:
		_mix_chunk_frames = found_chunk
		_period_blocks = found_blocks
		_phase_block = found_phase
		if found_blocks > 1:
			_interleave_locked = true
		print(PRINTSTR + "aligned: chunk=%d block %d of %d (contrast %.1f)" % [
			found_chunk, found_phase, found_blocks, found_score])

	_phase_abs = _consumed + _phase_block * _mix_chunk_frames
	_decided = true
	_pick_channel(frames)



func _loudest_block(frames: PackedVector2Array, chunk: int, blocks: int) -> int:
	var period: int = chunk * blocks
	if frames.size() < period or blocks <= 1: return 0
	var energy: PackedFloat32Array = PackedFloat32Array()
	energy.resize(blocks)
	var periods: int = frames.size() / period
	for pi: int in periods:
		for b: int in blocks:
			var base: int = pi * period + b * chunk
			var sum: float = 0.0
			var j: int = 0
			while j < chunk:
				var f: Vector2 = frames[base + j]
				sum += absf(f.x) + absf(f.y)
				j += SCAN_STRIDE
			energy[b] += sum
	var best_b: int = 0
	var best_e: float = energy[0]
	for b: int in range(1, blocks):
		if energy[b] > best_e:
			best_e = energy[b]
			best_b = b
	return best_b




func _shape_still_holds(frames: PackedVector2Array) -> bool:
	var chunk: int = _mix_chunk_frames
	var period: int = chunk * _period_blocks
	if frames.size() < period: return true

	if _peak_of(frames) < SIGNAL_FLOOR: return true
	var start: int = posmod(_phase_abs - _consumed, period)
	var mine: float = 0.0
	var others: float = 0.0
	var i: int = start
	while i + period <= frames.size():
		var b: int = 0
		while b < _period_blocks:
			var base: int = i + b * chunk
			var sum: float = 0.0
			var j: int = 0
			while j < chunk:
				var f: Vector2 = frames[base + j]
				sum += absf(f.x) + absf(f.y)
				j += SCAN_STRIDE
			if b == 0: mine += sum
			else: others += sum
			b += 1
		i += period
	if mine + others <= 0.0: return true

	if mine <= 0.0: return true
	return mine / maxf(1e-06, others / float(_period_blocks - 1)) >= CONTRAST_MIN * 0.4





var _channel_mode: int = 0


func _pick_channel(frames: PackedVector2Array) -> void :
	var left: float = 0.0
	var right: float = 0.0
	var chunk: int = _mix_chunk_frames
	var period: int = chunk * _period_blocks
	var i: int = posmod(_phase_abs - _consumed, period)
	while i + chunk <= frames.size():
		var j: int = 0
		while j < chunk:
			var f: Vector2 = frames[i + j]
			left += absf(f.x)
			right += absf(f.y)
			j += SCAN_STRIDE
		i += period
	if right > left * 4.0:
		_channel_mode = 1
		_use_right = true
	elif left > right * 4.0:
		_channel_mode = 0
		_use_right = false
	else:

		_channel_mode = 2
		_use_right = false




func _emit(frames: PackedVector2Array, allow_partial: bool = false) -> void :
	var chunk: int = _mix_chunk_frames
	var period: int = chunk * _period_blocks
	var i: int = posmod(_phase_abs - _consumed, period)
	while i < frames.size():
		var stop: int = mini(i + chunk, frames.size())
		if stop - i < chunk and not allow_partial: break
		var j: int = i
		while j < stop:
			var f: Vector2 = frames[j]
			var sample: float
			match _channel_mode:
				1: sample = f.y
				2: sample = (f.x + f.y) * 0.5
				_: sample = f.x
			_push_sample(sample)
			j += 1
		i += period
	_consumed += frames.size()












func _limit(sample: float) -> float:
	var magnitude: float = absf(sample)
	if magnitude <= LIMIT_KNEE: return sample
	var room: float = 1.0 - LIMIT_KNEE
	var shaped: float = LIMIT_KNEE + room * tanh((magnitude - LIMIT_KNEE) / room)
	return shaped if sample >= 0.0 else - shaped





func _push_sample(sample: float) -> void :
	if _pcm_used + 4 > _pcm.size():
		_pcm.resize(maxi(65536, _pcm.size() * 2))
	var value: int = int(clampf(_limit(sample), -1.0, 1.0) * 32767.0)
	_pcm.encode_s16(_pcm_used, value)
	_pcm.encode_s16(_pcm_used + 2, value)
	_pcm_used += 4
	_recorded_frames += 1


func _finished_pcm() -> PackedByteArray:
	if _pcm_used == _pcm.size(): return _pcm
	return _pcm.slice(0, _pcm_used)





const MAKEUP_TARGET_PEAK: float = 12000.0
const MAKEUP_MAX_GAIN: float = 16.0
const MAKEUP_MIN_PEAK: int = 40


func _makeup_gain(peak: int) -> float:
	if peak < MAKEUP_MIN_PEAK: return 1.0
	if float(peak) >= MAKEUP_TARGET_PEAK: return 1.0
	return minf(MAKEUP_MAX_GAIN, MAKEUP_TARGET_PEAK / float(peak))


func _scale_pcm(pcm: PackedByteArray, gain: float) -> PackedByteArray:
	if pcm.is_empty() or is_equal_approx(gain, 1.0): return pcm
	var out: PackedByteArray = pcm.duplicate()
	var i: int = 0
	while i + 1 < out.size():
		var s: int = out.decode_s16(i)
		var v: int = int(clampf(float(s) * gain, -32768.0, 32767.0))
		out.encode_s16(i, v)
		i += 2
	return out


func _pcm_to_wav(pcm: PackedByteArray) -> AudioStreamWAV:
	var wav: AudioStreamWAV = AudioStreamWAV.new()
	wav.format = AudioStreamWAV.FORMAT_16_BITS
	wav.mix_rate = maxi(1, int(AudioServer.get_mix_rate()))

	wav.stereo = true
	wav.loop_mode = AudioStreamWAV.LOOP_DISABLED
	if pcm.size() % 4 != 0:
		pcm = pcm.slice(0, pcm.size() - (pcm.size() % 4))
	wav.data = pcm
	return wav


func _pcm_peak(pcm: PackedByteArray) -> int:
	var peak: int = 0
	var i: int = 0
	var limit: int = mini(pcm.size(), 400000)
	while i + 1 < limit:
		var s: int = pcm.decode_s16(i)
		var a: int = absi(s)
		if a > peak:
			peak = a
		i += 2
	return peak


func _wav_peak(wav: AudioStreamWAV) -> int:
	if wav == null:
		return 0
	return _pcm_peak(wav.data)


func _init() -> void :
	_initialize_player()
	_initialize_warmup_timer()


func _ready() -> void :
	_ensure_capture_effect()
