extends Node














const SAVE_PATH: String = "user://game/mic_crust_presets.json"




const PRESET_FIELDS: Array[String] = [
	"mic_crust_compressor_on", "mic_crust_compressor_threshold", "mic_crust_compressor_gain", 
	"mic_crust_cutoff_on", "mic_crust_cutoff_low_pass", "mic_crust_cutoff_high_pass", 
	"mic_crust_limiter_on", "mic_crust_limiter_ceilingdb", "mic_crust_limiter_thresholddb", 
	"mic_crust_distortion_on", "mic_crust_distortion_pre_gain", "mic_crust_distortion_drive", "mic_crust_distortion_post_gain", 
	"mic_crust_sample_rate_on", "mic_crust_sample_rate_index", 
	"mic_crust_mic_input", "mic_crust_mic_multiplier", 
	"mic_crust_reverb_on", "mic_crust_reverb_room_size", "mic_crust_reverb_wet", 
	"mic_crust_delay_on", "mic_crust_delay_time_ms", "mic_crust_delay_feedback_db", 
	"mic_crust_panner_on", "mic_crust_panner_pan", 
	"mic_crust_pitch_on", "mic_crust_pitch_scale", 
]





const _BASELINE: Dictionary = {
	"mic_crust_compressor_on": false, "mic_crust_compressor_threshold": 0.0, "mic_crust_compressor_gain": 9.0, 
	"mic_crust_cutoff_on": false, "mic_crust_cutoff_low_pass": 16000, "mic_crust_cutoff_high_pass": 0, 
	"mic_crust_limiter_on": false, "mic_crust_limiter_ceilingdb": -10.0, "mic_crust_limiter_thresholddb": -5.0, 
	"mic_crust_distortion_on": false, "mic_crust_distortion_pre_gain": 0.0, "mic_crust_distortion_drive": 0.0, "mic_crust_distortion_post_gain": 6.0, 
	"mic_crust_sample_rate_on": false, "mic_crust_sample_rate_index": 0, 
	"mic_crust_mic_input": 1.0, "mic_crust_mic_multiplier": 1.0, 
	"mic_crust_reverb_on": false, "mic_crust_reverb_room_size": 0.5, "mic_crust_reverb_wet": 0.5, 
	"mic_crust_delay_on": false, "mic_crust_delay_time_ms": 250.0, "mic_crust_delay_feedback_db": -6.0, 
	"mic_crust_panner_on": false, "mic_crust_panner_pan": 0.0, 
	"mic_crust_pitch_on": false, "mic_crust_pitch_scale": 1.0, 
}




const _STARTER_OVERRIDES: Dictionary = {
	"Robot": {
		"mic_crust_distortion_on": true, "mic_crust_distortion_pre_gain": 3.0, "mic_crust_distortion_drive": 0.5, "mic_crust_distortion_post_gain": -3.0, 
		"mic_crust_cutoff_on": true, "mic_crust_cutoff_high_pass": 300, "mic_crust_cutoff_low_pass": 3400, 
	}, 
	"Radio": {
		"mic_crust_sample_rate_on": true, "mic_crust_sample_rate_index": 2, 
		"mic_crust_cutoff_on": true, "mic_crust_cutoff_high_pass": 500, "mic_crust_cutoff_low_pass": 4000, 
		"mic_crust_compressor_on": true, "mic_crust_compressor_threshold": -12.0, "mic_crust_compressor_gain": 6.0, 
	}, 
	"Cave": {
		"mic_crust_reverb_on": true, "mic_crust_reverb_room_size": 0.9, "mic_crust_reverb_wet": 0.6, 
	}, 
	"Echo Chamber": {
		"mic_crust_delay_on": true, "mic_crust_delay_time_ms": 350.0, "mic_crust_delay_feedback_db": -8.0, 
		"mic_crust_reverb_on": true, "mic_crust_reverb_room_size": 0.6, "mic_crust_reverb_wet": 0.3, 
	}, 
	"Off to the Side": {
		"mic_crust_panner_on": true, "mic_crust_panner_pan": 0.7, 
	}, 
}

signal presets_changed

var _saved_presets: Dictionary = {}


func _ready() -> void :
	_load_from_disk()




	if _saved_presets.is_empty():
		for preset_name: String in _STARTER_OVERRIDES:
			var full_preset: Dictionary = _BASELINE.duplicate()
			full_preset.merge(_STARTER_OVERRIDES[preset_name], true)
			_saved_presets[preset_name] = full_preset
		save_current_as("Default")


func get_preset_names() -> Array[String]:
	var names: Array[String] = []
	for n: String in _saved_presets.keys(): names.append(n)
	return names


func save_current_as(preset_name: String) -> void :
	preset_name = preset_name.strip_edges()
	if preset_name.is_empty(): return
	var captured: Dictionary = {}
	for field: String in PRESET_FIELDS: captured[field] = Profile.get(field)
	_saved_presets[preset_name] = captured
	_save_to_disk()
	presets_changed.emit()


func delete_preset(preset_name: String) -> void :
	if _saved_presets.erase(preset_name):
		_save_to_disk()
		presets_changed.emit()


func apply_preset(preset_name: String) -> void :
	var data: Dictionary = _saved_presets.get(preset_name, {})
	for field: String in PRESET_FIELDS:
		if data.has(field): Profile.set(field, data[field])


func _save_to_disk() -> void :
	var file: FileAccess = FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if file:
		file.store_string(JSON.stringify(_saved_presets))
		file.close()
	else:
		push_error("MicCrustPresets | Failed to save presets: error %s" % FileAccess.get_open_error())


func _load_from_disk() -> void :
	if !FileAccess.file_exists(SAVE_PATH): return
	var file: FileAccess = FileAccess.open(SAVE_PATH, FileAccess.READ)
	if !file: return
	var parsed: Variant = JSON.parse_string(file.get_as_text())
	file.close()
	if parsed is Dictionary: _saved_presets = parsed
